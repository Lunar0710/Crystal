package dev.crystal.client.module.misc;

import dev.crystal.client.gui.CrystalTitleScreen;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import net.minecraft.class_310;
import net.minecraft.class_442;

/** Swaps vanilla's title screen for Crystal's (see MixinMinecraftClient#setScreen). */
public class CustomMainMenu extends Module {

    public CustomMainMenu() {
        super("CustomMainMenu", "Crystal's own main menu instead of the vanilla title screen", ModuleCategory.MISC);
        setEnabled(true);
    }

    @Override
    public void onEnable() {
        swapIfShowing(true);
    }

    @Override
    public void onDisable() {
        swapIfShowing(false);
    }

    /** Applies the change right away when toggled while sitting in the main menu. */
    private void swapIfShowing(boolean toCrystal) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1755 == null) return;
        if (toCrystal && mc.field_1755 instanceof class_442) mc.method_1507(new CrystalTitleScreen());
        if (!toCrystal && mc.field_1755 instanceof CrystalTitleScreen) mc.method_1507(new class_442());
    }
}
