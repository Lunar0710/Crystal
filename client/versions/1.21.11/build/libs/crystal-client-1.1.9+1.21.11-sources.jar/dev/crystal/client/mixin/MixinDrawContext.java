package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.render.ScrollableTooltips;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

/**
 * Translates the whole tooltip draw up/down by ScrollableTooltips' offset,
 * rather than reimplementing this method's internal layout — every component
 * type (text, item icon, image) still renders exactly like vanilla, just
 * shifted, and there's nothing here that can desync from vanilla's own
 * positioning math since that math never gets touched.
 */
@Mixin(class_332.class)
public class MixinDrawContext {

    @Inject(
        method = "setTooltipForNextFrameInternal(Lnet/minecraft/client/gui/Font;Ljava/util/List;IILnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipPositioner;Lnet/minecraft/resources/Identifier;Z)V",
        at = @At("HEAD")
    )
    private void onDrawTooltipStart(class_327 textRenderer, List<class_5684> components, int x, int y,
                                     class_8000 positioner, class_2960 texture, boolean bordered, CallbackInfo ci) {
        ScrollableTooltips module = scrollModule();
        if (module == null || module.getOffset() == 0f) return;

        class_332 self = (class_332) (Object) this;
        self.method_51448().pushMatrix();
        self.method_51448().translate(0, module.getOffset());
    }

    @Inject(
        method = "setTooltipForNextFrameInternal(Lnet/minecraft/client/gui/Font;Ljava/util/List;IILnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipPositioner;Lnet/minecraft/resources/Identifier;Z)V",
        at = @At("RETURN")
    )
    private void onDrawTooltipEnd(class_327 textRenderer, List<class_5684> components, int x, int y,
                                   class_8000 positioner, class_2960 texture, boolean bordered, CallbackInfo ci) {
        ScrollableTooltips module = scrollModule();
        if (module == null || module.getOffset() == 0f) return;

        ((class_332) (Object) this).method_51448().popMatrix();
    }

    private ScrollableTooltips scrollModule() {
        if (CrystalClient.getInstance() == null) return null;
        return CrystalClient.getInstance().getModuleManager().getModuleByName("ScrollableTooltips")
                .filter(m -> m.isEnabled())
                .map(m -> (ScrollableTooltips) m)
                .orElse(null);
    }
}
