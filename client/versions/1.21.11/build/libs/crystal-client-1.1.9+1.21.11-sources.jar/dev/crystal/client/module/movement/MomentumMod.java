package dev.crystal.client.module.movement;

import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_243;
import net.minecraft.class_310;

/** Categorized under Movement since it's about movement, but rendered like any other HUD line — CrystalHUD doesn't care about category. */
public class MomentumMod extends HudModule {

        public MomentumMod() {
        super("MomentumMod", "Visualizes your current movement vector on screen — display only, no speed change", ModuleCategory.MOVEMENT, 4, 208);
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null) return "Momentum: N/A";

        class_243 v = player.method_18798();
        double speed = Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350) * 20; // blocks/tick -> blocks/second
        return String.format("Momentum: %.2f b/s", speed);
    }
}
