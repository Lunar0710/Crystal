package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.gui.GuiRender;
import dev.crystal.client.module.hud.Scoreboard;
import dev.crystal.client.module.misc.ActionBarDisplay;
import dev.crystal.client.module.render.Crosshair;
import dev.crystal.client.module.render.Titles;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9011;
import net.minecraft.class_9779;

@Mixin(class_329.class)
public class MixinInGameHud {

    @Shadow private class_2561 overlayMessageString;
    @Shadow private int overlayMessageTime;
    @Shadow private class_2561 title;
    @Shadow private class_2561 subtitle;
    @Shadow private int titleTime;
    @Shadow private int titleFadeInTime;
    @Shadow private int titleStayTime;
    @Shadow private int titleFadeOutTime;

    @Unique private List<class_9011> crystal$sidebarEntries = List.of();
    @Unique private String crystal$sidebarTitle = "";
    @Unique private int crystal$sidebarWidth;
    @Unique private class_266 crystal$sidebarObjective;
    @Unique private boolean crystal$sidebarShowScores;
    @Unique private long crystal$sidebarBuiltAt;

    @Inject(method = "renderOverlayMessage", at = @At("HEAD"), cancellable = true)
    private void onRenderOverlayMessage(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null || overlayMessageString == null || overlayMessageTime <= 0) return;

        ActionBarDisplay module = CrystalClient.getInstance().getModuleManager().getModuleByName("ActionBar")
                .filter(m -> m.isEnabled())
                .map(m -> (ActionBarDisplay) m)
                .orElse(null);
        if (module == null) return;

        ci.cancel();

        class_329 self = (class_329) (Object) this;
        class_327 textRenderer = self.method_1756();

        // Same fade curve as vanilla: fully visible, then fading out over the last 20 ticks.
        int alpha = overlayMessageTime > 20 ? 255 : Math.max(0, overlayMessageTime * 255 / 20);

        int width = context.method_51421();
        int height = context.method_51443();
        int textWidth = textRenderer.method_27525(overlayMessageString);
        int x = (width - textWidth) / 2;
        int y = height - 68;

        if (module.isShowBackground()) {
            int bgAlpha = (alpha / 2) << 24;
            context.method_25294(x - 4, y - 3, x + textWidth + 4, y + 10, bgAlpha | 0x000000);
        }

        int color = (module.getTextColor() & 0x00FFFFFF) | (alpha << 24);
        context.method_51439(textRenderer, overlayMessageString, x, y, color, true);
    }

    @Inject(method = "renderTitle", at = @At("HEAD"), cancellable = true)
    private void onRenderTitleAndSubtitle(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null || title == null || titleTime <= 0) return;

        Titles module = CrystalClient.getInstance().getModuleManager().getModuleByName("Titles")
                .filter(m -> m.isEnabled())
                .map(m -> (Titles) m)
                .orElse(null);
        if (module == null) return;

        ci.cancel();

        class_329 self = (class_329) (Object) this;
        class_327 textRenderer = self.method_1756();
        float remaining = titleTime - tickCounter.method_60637(false);

        int alpha;
        if (titleTime > titleFadeOutTime + titleStayTime) {
            float fadeIn = 1f - (remaining - (titleFadeOutTime + titleStayTime)) / titleFadeInTime;
            alpha = Math.round(Math.max(0f, Math.min(1f, fadeIn)) * 255f);
        } else if (remaining <= titleFadeOutTime) {
            alpha = Math.round(Math.max(0f, remaining / Math.max(1, titleFadeOutTime)) * 255f);
        } else {
            alpha = 255;
        }

        float scale = module.getScale();
        int width = context.method_51421();
        int height = context.method_51443();

        context.method_51448().pushMatrix();
        context.method_51448().translate(width / 2f, height / 2f);
        context.method_51448().scale(scale, scale);

        int titleColor = (module.getTitleColor() & 0x00FFFFFF) | (alpha << 24);
        context.method_27534(textRenderer, title, 0, -20, titleColor);

        if (subtitle != null) {
            int subtitleColor = (module.getSubtitleColor() & 0x00FFFFFF) | (alpha << 24);
            context.method_27534(textRenderer, subtitle, 0, 5, subtitleColor);
        }

        context.method_51448().popMatrix();
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void onRenderCrosshair(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null) return;

        Crosshair module = CrystalClient.getInstance().getModuleManager().getModuleByName("Crosshair")
                .filter(m -> m.isEnabled())
                .map(m -> (Crosshair) m)
                .orElse(null);
        if (module == null) return;

        ci.cancel();

        module.draw(context, context.method_51421() / 2, context.method_51443() / 2);
    }

    @Inject(
        method = "displayScoreboardSidebar(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/world/scores/Objective;)V",
        at = @At("HEAD"), cancellable = true
    )
    private void onRenderScoreboardSidebar(class_332 context, class_266 objective, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null) return;

        Scoreboard module = CrystalClient.getInstance().getModuleManager().getModuleByName("Scoreboard")
                .filter(m -> m.isEnabled())
                .map(m -> (Scoreboard) m)
                .orElse(null);
        if (module == null) return;

        ci.cancel();

        class_329 self = (class_329) (Object) this;
        class_327 textRenderer = self.method_1756();

        // Copy, filter, sort and measure the sidebar at most every 50 ms (one
        // server tick) instead of every frame. On servers with a full
        // scoreboard that was noticeable garbage at high frame rates.
        long now = System.currentTimeMillis();
        boolean showScores = module.isShowScores();
        if (objective != crystal$sidebarObjective || showScores != crystal$sidebarShowScores || now - crystal$sidebarBuiltAt >= 50) {
            List<class_9011> built = new ArrayList<>(objective.method_1117().method_1184(objective));
            built.removeIf(class_9011::method_55385);
            built.sort(Comparator.comparingInt(class_9011::comp_2128).reversed());
            if (built.size() > 15) built = new ArrayList<>(built.subList(0, 15));

            String builtTitle = objective.method_1114().getString();
            int builtWidth = textRenderer.method_1727(builtTitle) + 8;
            for (class_9011 entry : built) {
                int lineWidth = textRenderer.method_27525(entry.method_55387());
                if (showScores) lineWidth += textRenderer.method_1727(" " + entry.comp_2128()) + 4;
                builtWidth = Math.max(builtWidth, lineWidth + 8);
            }

            crystal$sidebarEntries = built;
            crystal$sidebarTitle = builtTitle;
            crystal$sidebarWidth = builtWidth;
            crystal$sidebarObjective = objective;
            crystal$sidebarShowScores = showScores;
            crystal$sidebarBuiltAt = now;
        }

        List<class_9011> entries = crystal$sidebarEntries;
        String title = crystal$sidebarTitle;
        int width = crystal$sidebarWidth;
        int lineHeight = 9;

        int screenHeight = context.method_51443();
        int panelHeight = lineHeight * (entries.size() + 1) + 4;
        int x = context.method_51421() - width - 4;
        int y = Math.max(4, (screenHeight - panelHeight) / 3);

        GuiRender.roundedRect(context, x, y, x + width, y + panelHeight, module.getBackgroundColor());
        context.method_25300(textRenderer, title, x + width / 2, y + 2, module.getTitleColor());

        int rowY = y + lineHeight + 4;
        for (class_9011 entry : entries) {
            context.method_27535(textRenderer, entry.method_55387(), x + 4, rowY, module.getTextColor());
            if (module.isShowScores()) {
                String value = String.valueOf(entry.comp_2128());
                context.method_25303(textRenderer, value, x + width - textRenderer.method_1727(value) - 4, rowY, module.getTitleColor());
            }
            rowY += lineHeight;
        }
    }
}
