package dev.crystal.client.module.misc;

import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.ButtonSetting;
import dev.crystal.client.module.HiddenTextSetting;
import dev.crystal.client.module.KeybindSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_3675;

/**
 * Three resource pack sets. "Save" stores the packs that are on right now in a
 * slot, "Load" (or the slot's key) switches to exactly that set. Useful for
 * jumping between a PvP pack and a building pack without the pack menu.
 */
public class PackOrganizer extends Module {

    private static final int SLOTS = 3;

    /** Enabled pack ids per slot, joined with '\n' (pack ids never contain newlines). */
    private final String[] slotPacks = {"", "", ""};
    private final int[] slotKeys = {-1, -1, -1};
    private final boolean[] keyWasDown = new boolean[SLOTS];

    private final Consumer<TickEvent> tickListener = e -> checkKeys();

    public PackOrganizer() {
        super("PackOrganizer", "Save up to three resource pack sets and switch between them with one click or key", ModuleCategory.MISC);
        setEnabled(true);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    public void save(int slot) {
        class_3283 manager = mc.method_1520();
        slotPacks[slot] = String.join("\n", manager.method_29210());
        notify("Set " + (slot + 1) + " gespeichert (" + describe(slot) + ")");
        CrystalClient.getInstance().getConfigManager().save();
    }

    public void load(int slot) {
        if (slotPacks[slot].isEmpty()) {
            notify("Set " + (slot + 1) + " ist leer. Erst speichern.");
            return;
        }
        class_3283 manager = mc.method_1520();
        manager.method_14445();
        List<String> wanted = new ArrayList<>(Arrays.asList(slotPacks[slot].split("\n")));
        // A pack that was deleted since saving is skipped instead of failing the switch.
        wanted.removeIf(id -> manager.method_14449(id) == null);
        manager.method_14447(wanted);
        mc.field_1690.method_49598(manager);
        notify("Set " + (slot + 1) + " geladen");
    }

    /** Pack names in a slot, for the button label and chat message. */
    private String describe(int slot) {
        if (slotPacks[slot].isEmpty()) return "leer";
        class_3283 manager = mc.method_1520();
        List<String> names = new ArrayList<>();
        for (String id : slotPacks[slot].split("\n")) {
            if (id.equals("vanilla") || id.startsWith("fabric") || id.startsWith("crystal:")) continue;
            class_3288 profile = manager.method_14449(id);
            names.add(profile != null ? profile.method_14457().getString() : id.replace("file/", ""));
        }
        return names.isEmpty() ? "Standard" : String.join(", ", names);
    }

    private void checkKeys() {
        if (mc.field_1755 != null) return;
        for (int i = 0; i < SLOTS; i++) {
            boolean down = slotKeys[i] > 0 && class_3675.method_15987(mc.method_22683(), slotKeys[i]);
            if (down && !keyWasDown[i]) load(i);
            keyWasDown[i] = down;
        }
    }

    private void notify(String message) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) client.field_1724.method_7353(class_2561.method_43470("[Crystal] " + message), true);
    }

    @Override
    public List<Setting<?>> getSettings() {
        List<Setting<?>> list = new ArrayList<>();
        for (int i = 0; i < SLOTS; i++) {
            final int slot = i;
            list.add(new ButtonSetting("Set " + (slot + 1) + ": " , () -> "Laden", () -> load(slot)) {
                @Override public String getName() { return "Set " + (slot + 1) + ": " + describe(slot); }
            });
            list.add(new ButtonSetting("Set " + (slot + 1) + " speichern", () -> "Aktuelle speichern", () -> save(slot)));
            list.add(new KeybindSetting("Set " + (slot + 1) + " Taste", () -> slotKeys[slot], v -> slotKeys[slot] = v, -1));
            list.add(new HiddenTextSetting("Set " + (slot + 1) + " Packs", () -> slotPacks[slot], v -> slotPacks[slot] = v));
        }
        return list;
    }
}
