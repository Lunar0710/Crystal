package dev.crystal.client.module.hud;

import net.minecraft.class_310;

/** Number of players in the server's tab list. */
public class PlayerCountDisplay extends HudModule {

    public PlayerCountDisplay() {
        super("PlayerCount", "Shows how many players are online on the server", 4, 212);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        var handler = mc.method_1562();
        if (handler == null) return "Players: -";
        return "Players: " + handler.method_2880().size();
    }
}
