package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.render.FogCustomizer;
import net.minecraft.class_11398;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Overrides the normal overworld fog's start/end distances after vanilla computes them. */
@Mixin(class_11398.class)
public class MixinAtmosphericFogModifier {

    @Inject(method = "setupFog", at = @At("TAIL"))
    private void onApplyStartEndModifier(class_7285 fogData, class_4184 camera, class_638 world, float viewDistance, class_9779 tickCounter, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null) return;

        FogCustomizer module = CrystalClient.getInstance().getModuleManager().getEnabled(FogCustomizer.class);
        if (module == null) return;

        if (module.isDisableFog()) {
            fogData.field_60582 = fogData.field_60585;
            fogData.field_60584 = fogData.field_60585 + 1f;
            return;
        }

        float multiplier = module.getDistanceMultiplier();
        fogData.field_60582 *= multiplier;
        fogData.field_60584 *= multiplier;
    }
}
