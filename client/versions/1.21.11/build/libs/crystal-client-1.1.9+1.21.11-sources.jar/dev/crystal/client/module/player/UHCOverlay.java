package dev.crystal.client.module.player;

import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_310;

public class UHCOverlay extends HudModule {

        public UHCOverlay() {
        super("UHCOverlay", "Replaces the hunger bar with a UHC-style health/hunger overlay", ModuleCategory.PLAYER, 4, 256);
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null) return "";
        return String.format("HP: %.1f  Hunger: %d", player.method_6032(), player.method_7344().method_7586());
    }
}
