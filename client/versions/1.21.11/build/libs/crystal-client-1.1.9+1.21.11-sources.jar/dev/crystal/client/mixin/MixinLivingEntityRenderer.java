package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.render.NameTags;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** NameTags "Show Own Nametag": vanilla never labels the camera entity, so allow it in third person. */
@Mixin(class_922.class)
public class MixinLivingEntityRenderer {

    @Inject(method = "shouldShowName(Lnet/minecraft/world/entity/LivingEntity;D)Z", at = @At("RETURN"), cancellable = true)
    private void crystal$ownNametag(class_1309 entity, double squaredDistance, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) return;
        class_310 mc = class_310.method_1551();
        if (entity != mc.field_1724 || mc.field_1690.method_31044().method_31034() || !class_310.method_1498()) return;
        CrystalClient client = CrystalClient.getInstance();
        if (client == null) return;
        NameTags module = client.getModuleManager().getEnabled(NameTags.class);
        if (module != null && module.isShowOwn() && !entity.method_5767()) cir.setReturnValue(true);
    }
}
