package dev.crystal.client.module.hud;

import java.util.Locale;
import net.minecraft.class_310;

/** Name of the biome at the player's feet, e.g. "Biome: Dark Forest". */
public class BiomeDisplay extends HudModule {

    public BiomeDisplay() {
        super("BiomeDisplay", "Shows the biome you are standing in", 4, 188);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return "Biome: -";
        return mc.field_1687.method_23753(mc.field_1724.method_24515()).method_40230()
                .map(key -> "Biome: " + pretty(key.method_29177().method_12832()))
                .orElse("Biome: -");
    }

    /** "dark_forest" -> "Dark Forest". */
    private static String pretty(String path) {
        StringBuilder out = new StringBuilder();
        for (String word : path.split("_")) {
            if (word.isEmpty()) continue;
            if (out.length() > 0) out.append(' ');
            out.append(word.substring(0, 1).toUpperCase(Locale.ROOT)).append(word.substring(1));
        }
        return out.toString();
    }
}
