package dev.crystal.client.module.hud;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Setting;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/** The address of the server you're on, optionally with the server's logo in front. */
public class ServerAddressDisplay extends HudModule {

    private static final class_2960 LOGO_ID = class_2960.method_60655(CrystalClient.MOD_ID, "hud/server_logo");
    private static final class_2960 UNKNOWN_LOGO = class_2960.method_60656("textures/misc/unknown_server.png");

    private boolean showLogo = true;

    /** The favicon bytes last uploaded (or tried) as {@link #LOGO_ID}, to spot a server change. */
    private byte[] uploadedFavicon = null;
    private boolean uploadFailed = false;

    public ServerAddressDisplay() {
        // Below the icon Armor HUD, which runs from y=80 to about 153.
        super("ServerAddress", "Displays the address of the server you're connected to", 4, 158);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.method_1496()) return "Singleplayer";

        var entry = mc.method_1558();
        return entry != null ? entry.field_3761 : "";
    }

    @Override
    public class_2960 getIcon() {
        class_310 mc = class_310.method_1551();
        if (!showLogo || mc.method_1496()) return null;
        var entry = mc.method_1558();
        if (entry == null) return null;

        byte[] favicon = entry.method_49306();
        if (favicon == null) return UNKNOWN_LOGO;
        if (!Arrays.equals(favicon, uploadedFavicon)) {
            uploadedFavicon = favicon;
            try {
                class_1011 image = class_1011.method_49277(favicon);
                // Replaces (and frees) the previous server's logo.
                mc.method_1531().method_4616(LOGO_ID, new class_1043(LOGO_ID::toString, image));
                uploadFailed = false;
            } catch (Exception e) {
                CrystalClient.LOGGER.warn("[Crystal] Server logo could not be read: {}", e.getMessage());
                uploadFailed = true; // same broken image isn't retried every frame
            }
        }
        return uploadFailed ? UNKNOWN_LOGO : LOGO_ID;
    }

    @Override
    protected List<Setting<?>> getExtraSettings() {
        return List.of(new BooleanSetting("Show Logo", () -> showLogo, v -> showLogo = v, true));
    }
}
