package dev.crystal.client.module.hud;

import net.minecraft.class_310;

public class DayCounter extends HudModule {

        public DayCounter() {
        super("DayCounter", "Displays the current in-world day count", 4, 52);
    }

    @Override
    public String getText() {
        var world = class_310.method_1551().field_1687;
        if (world == null) return "Day: N/A";
        // 24000 ticks per Minecraft day; day 1 starts at tick 0.
        long day = world.method_8532() / 24000L + 1;
        return "Day: " + day;
    }
}
