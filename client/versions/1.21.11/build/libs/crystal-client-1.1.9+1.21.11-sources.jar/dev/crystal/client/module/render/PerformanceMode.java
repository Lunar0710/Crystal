package dev.crystal.client.module.render;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.SliderSetting;
import dev.crystal.client.util.CrystalPaths;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_4063;
import net.minecraft.class_4066;

/**
 * Turns down the vanilla video options that cost the most on weak hardware,
 * and puts every one of them back exactly as it was when switched off.
 *
 * The original values are written to a backup file before anything changes.
 * Minecraft saves options.txt on its own schedule, so without that file a game
 * closed while this was on would come back with the reduced values as the
 * "originals" and the player's real settings would be gone for good.
 */
public class PerformanceMode extends Module {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private float viewDistance = 8f;
    private float simulationDistance = 6f;
    private boolean reduceParticles = true;
    private boolean disableClouds = true;
    private boolean disableEntityShadows = true;
    private boolean disableBiomeBlend = true;

    private boolean applied = false;
    private final Consumer<TickEvent> tickListener = this::onTick;

    public PerformanceMode() {
        super("PerformanceMode", "Lowers the most expensive video settings for more FPS on weaker PCs", ModuleCategory.RENDER);
    }

    @Override
    public void onEnable() {
        // Deferred to the next tick: modules can be enabled from the saved
        // config while the client is still starting and options don't exist yet.
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
        restore();
    }

    private void onTick(TickEvent event) {
        if (applied || event.getClient().field_1690 == null) return;
        apply(event.getClient().field_1690);
    }

    private void apply(class_315 o) {
        Path backup = backupFile();
        // Never overwrite an existing backup: if one is there, it already holds
        // the real originals from before an earlier session.
        if (!Files.exists(backup)) {
            JsonObject saved = new JsonObject();
            saved.addProperty("viewDistance", o.method_42503().method_41753());
            saved.addProperty("simulationDistance", o.method_42510().method_41753());
            saved.addProperty("particles", o.method_42475().method_41753().name());
            saved.addProperty("clouds", o.method_42528().method_41753().name());
            saved.addProperty("entityShadows", o.method_42435().method_41753());
            saved.addProperty("biomeBlend", o.method_41805().method_41753());
            try {
                Files.createDirectories(backup.getParent());
                Files.writeString(backup, GSON.toJson(saved));
            } catch (IOException e) {
                // Without a backup we can't promise a clean restore, so change nothing.
                CrystalClient.LOGGER.error("[Crystal] Leistungsmodus: Sicherung fehlgeschlagen, keine Optionen geändert: {}", e.getMessage());
                applied = true;
                return;
            }
        }

        o.method_42503().method_41748(Math.min(o.method_42503().method_41753(), Math.round(viewDistance)));
        o.method_42510().method_41748(Math.min(o.method_42510().method_41753(), Math.round(simulationDistance)));
        if (reduceParticles && o.method_42475().method_41753() == class_4066.field_18197) o.method_42475().method_41748(class_4066.field_18198);
        if (disableClouds) o.method_42528().method_41748(class_4063.field_18162);
        if (disableEntityShadows) o.method_42435().method_41748(false);
        if (disableBiomeBlend) o.method_41805().method_41748(0);
        o.method_1640();
        applied = true;
    }

    private void restore() {
        applied = false;
        class_310 mc = class_310.method_1551();
        Path backup = backupFile();
        if (mc.field_1690 == null || !Files.exists(backup)) return;

        try {
            JsonObject saved = GSON.fromJson(Files.readString(backup), JsonObject.class);
            class_315 o = mc.field_1690;
            o.method_42503().method_41748(saved.get("viewDistance").getAsInt());
            o.method_42510().method_41748(saved.get("simulationDistance").getAsInt());
            o.method_42475().method_41748(class_4066.valueOf(saved.get("particles").getAsString()));
            o.method_42528().method_41748(class_4063.valueOf(saved.get("clouds").getAsString()));
            o.method_42435().method_41748(saved.get("entityShadows").getAsBoolean());
            o.method_41805().method_41748(saved.get("biomeBlend").getAsInt());
            o.method_1640();
            Files.delete(backup);
        } catch (Exception e) {
            // Keep the backup file so nothing is lost; the next disable retries.
            CrystalClient.LOGGER.error("[Crystal] Leistungsmodus: Wiederherstellen fehlgeschlagen, Sicherung bleibt erhalten: {}", e.getMessage());
        }
    }

    private static Path backupFile() {
        return CrystalPaths.root().resolve("config").resolve("performance_mode_backup.json");
    }

    /** Re-applies with the new values when a setting changes while active. */
    private void reapply() {
        if (!isEnabled() || class_310.method_1551().field_1690 == null) return;
        apply(class_310.method_1551().field_1690);
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new SliderSetting("Max View Distance", () -> viewDistance, v -> { viewDistance = v; reapply(); }, 2f, 16f, 1f, 0),
                new SliderSetting("Max Simulation Distance", () -> simulationDistance, v -> { simulationDistance = v; reapply(); }, 5f, 12f, 1f, 0),
                new BooleanSetting("Fewer Particles", () -> reduceParticles, v -> { reduceParticles = v; reapply(); }, true),
                new BooleanSetting("No Clouds", () -> disableClouds, v -> { disableClouds = v; reapply(); }, true),
                new BooleanSetting("No Entity Shadows", () -> disableEntityShadows, v -> { disableEntityShadows = v; reapply(); }, true),
                new BooleanSetting("No Biome Blend", () -> disableBiomeBlend, v -> { disableBiomeBlend = v; reapply(); }, true)
        );
    }
}
