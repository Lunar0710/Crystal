package dev.crystal.client.module.hud;

import net.minecraft.class_310;

public class FPSDisplay extends HudModule {

        public FPSDisplay() {
        super("FPS", "Displays current frames per second", 4, 16);
        setEnabled(true);
    }

    @Override
    public String getText() {
        return "FPS: " + class_310.method_1551().method_47599();
    }
}
