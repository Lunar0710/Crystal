package dev.crystal.client.module.misc;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.SliderSetting;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;

/**
 * Remembers the last multiplayer server you were on and rejoins it after a
 * disconnect. Never triggers from quitting to the title screen yourself —
 * only from actually landing on {@link class_419}.
 */
public class AutoReconnect extends Module {

    private float delaySeconds = 3f;
    private class_642 lastServer;
    private long disconnectedAt = 0;
    private boolean attempted = false;

    private final Consumer<TickEvent> tickListener = this::onTick;

    public AutoReconnect() {
        super("AutoReconnect", "Automatically rejoins the server after a disconnect", ModuleCategory.MISC);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();

        // Remember the server while actually connected to one.
        class_642 current = mc.method_1558();
        if (current != null) {
            lastServer = current;
            disconnectedAt = 0;
            attempted = false;
            return;
        }

        if (!(mc.field_1755 instanceof class_419) || lastServer == null) return;

        long now = System.currentTimeMillis();
        if (disconnectedAt == 0) {
            disconnectedAt = now;
            return;
        }
        if (attempted || now - disconnectedAt < delaySeconds * 1000) return;

        attempted = true;
        class_639 address = class_639.method_2950(lastServer.field_3761);
        class_412.method_36877(mc.field_1755, mc, address, lastServer, false,
                new class_9112(Map.of(), Map.of(), false));
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(new SliderSetting("Delay (s)", () -> delaySeconds, v -> delaySeconds = v, 1f, 15f, 1f, 0));
    }
}
