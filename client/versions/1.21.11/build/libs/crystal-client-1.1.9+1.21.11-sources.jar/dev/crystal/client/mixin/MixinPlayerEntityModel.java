package dev.crystal.client.mixin;

import dev.crystal.client.render.Skins3DFeatureRenderer;
import net.minecraft.class_10055;
import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 3D Skins: hides the flat outer layer while the voxel version is drawn instead. */
@Mixin(class_591.class)
public class MixinPlayerEntityModel {

    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V", at = @At("TAIL"))
    private void crystal$hideFlatLayer(class_10055 state, CallbackInfo ci) {
        if (!Skins3DFeatureRenderer.activeFor(state)) return;
        class_591 model = (class_591) (Object) this;
        model.field_3394.field_3665 = false;
        model.field_3483.field_3665 = false;
        model.field_3484.field_3665 = false;
        model.field_3486.field_3665 = false;
        model.field_3482.field_3665 = false;
        model.field_3479.field_3665 = false;
    }
}
