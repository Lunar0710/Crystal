package dev.crystal.client.module.render;

import dev.crystal.client.module.EnumSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.SliderSetting;
import java.util.List;
import net.minecraft.class_1109;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

/**
 * A clear hit sound whenever you hit a player or mob, so hits are easy to hear
 * in loud fights. Only you hear it. Triggered from MixinClientPlayerInteractionManager.
 */
public class BetterSounds extends Module {

    private static final String DING = "Ding";
    private static final String XP = "XP";
    private static final String BELL = "Bell";
    private static final String ARROW = "Arrow Hit";

    private String sound = DING;
    private float volume = 60f;
    private float pitch = 1f;

    public BetterSounds() {
        super("BetterSounds", "Plays a clear hit sound when you hit a player or mob", ModuleCategory.RENDER);
    }

    public void onAttack(class_1297 target) {
        if (!(target instanceof class_1309)) return;
        class_3414 event = switch (sound) {
            case XP -> class_3417.field_14627;
            case BELL -> class_3417.field_14793.comp_349();
            case ARROW -> class_3417.field_15224;
            default -> class_3417.field_14622.comp_349();
        };
        class_310.method_1551().method_1483()
                .method_4873(class_1109.method_4757(event, pitch, volume / 100f));
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new EnumSetting("Hit Sound", () -> sound, v -> sound = v, List.of(DING, XP, BELL, ARROW)),
                new SliderSetting("Volume", () -> volume, v -> volume = v, 5f, 100f, 5f, 0),
                new SliderSetting("Pitch", () -> pitch, v -> pitch = v, 0.5f, 2f, 0.1f, 1));
    }
}
