package dev.crystal.client.render;

import dev.crystal.client.util.CosmeticLoadout;
import dev.crystal.client.util.CosmeticLoadout.Box;
import dev.crystal.client.util.CosmeticLoadout.Item;
import java.util.List;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_7833;

/**
 * Draws the launcher's hats, bandanas, masks, backpacks, wings and auras on the
 * local player.
 *
 * Shapes are not defined here: the launcher sends the exact boxes its 3D
 * preview draws (cosmeticShapes.ts) in cosmetics/loadout.json, so the preview
 * and the game always match. Those boxes are in skin pixels with y up and +z
 * towards the face; Minecraft's model space has y down and the face towards
 * -z, which is what the conversions below account for.
 */
public class CosmeticsFeatureRenderer extends class_3887<class_10055, class_591> {

    private static final class_2960 WHITE = class_2960.method_60655("crystal", "textures/cosmetics/white.png");
    private static final int GLOW_LIGHT = 0xF000F0;

    public CosmeticsFeatureRenderer(class_3883<class_10055, class_591> context) {
        super(context);
    }

    @Override
    public void submit(class_4587 matrices, class_11659 queue, int light, class_10055 state, float limbAngle, float limbDistance) {
        class_310 mc = class_310.method_1551();
        // Own player only, same as the cape: the loadout lives on this PC.
        if (mc.field_1724 == null || state.field_53528 != mc.field_1724.method_5628() || state.field_53333) return;
        if (CosmeticLoadout.isEmpty()) return;

        class_1921 layer = class_12249.method_75994(WHITE);
        class_591 model = method_17165();

        for (String slot : new String[]{CosmeticLoadout.HAT, CosmeticLoadout.BANDANA, CosmeticLoadout.MASK}) {
            Item item = CosmeticLoadout.get(slot);
            if (item == null || item.boxes().isEmpty()) continue;
            matrices.method_22903();
            model.field_3398.method_22703(matrices);
            matrices.method_22905(1 / 16f, 1 / 16f, 1 / 16f);
            // Head-centre space: the head cuboid spans y -8..0 in model space.
            matrices.method_46416(0f, -4f, 0f);
            submit(matrices, queue, layer, light, item.boxes(), 1);
            matrices.method_22909();
        }

        Item backpack = CosmeticLoadout.get(CosmeticLoadout.BACKPACK);
        Item wings = CosmeticLoadout.get(CosmeticLoadout.WINGS);
        if ((backpack != null && !backpack.boxes().isEmpty()) || (wings != null && !wings.boxes().isEmpty())) {
            matrices.method_22903();
            model.field_3391.method_22703(matrices);
            matrices.method_22905(1 / 16f, 1 / 16f, 1 / 16f);
            if (backpack != null) submit(matrices, queue, layer, light, backpack.boxes(), 1);
            if (wings != null) renderWings(matrices, queue, layer, light, wings, state.field_53328);
            matrices.method_22909();
        }

        Item aura = CosmeticLoadout.get(CosmeticLoadout.AURA);
        if (aura != null) renderAura(matrices, queue, layer, aura, state.field_53328);
    }

    /**
     * Both wings from the one right-wing shape: the left is mirrored. Each is
     * hinged on the upper back, swept backwards and flapping slowly.
     */
    private static void renderWings(class_4587 matrices, class_11659 queue, class_1921 layer, int light, Item wings, float age) {
        float flap = class_3532.method_15374(age * 0.12f) * 0.22f;
        for (int side : new int[]{1, -1}) {
            matrices.method_22903();
            // Hinge: upper back, just off the spine (model space: y down, +z = back).
            matrices.method_46416(side * 1.5f, 2.5f, 2.6f);
            // Positive x swings toward -z (front) for a positive angle, so the
            // right wing takes a negative one to sweep back, the left a positive one.
            matrices.method_22907(class_7833.field_40716.rotation(-side * (0.8f + flap)));
            submit(matrices, queue, layer, light, wings.boxes(), side);
            matrices.method_22909();
        }
    }

    /** A glowing ring of small cubes turning around the feet, bobbing gently. */
    private static void renderAura(class_4587 matrices, class_11659 queue, class_1921 layer, Item aura, float age) {
        matrices.method_22903();
        matrices.method_22905(1 / 16f, 1 / 16f, 1 / 16f);
        int count = 14;
        List<Box> boxes = new java.util.ArrayList<>(count * 2);
        for (int i = 0; i < count; i++) {
            float a = age * 0.05f + (float) (i * Math.PI * 2 / count);
            float bob = class_3532.method_15374(age * 0.09f + i * 0.9f) * 1.6f;
            float r = 11f + class_3532.method_15374(age * 0.04f + i) * 1.2f;
            // Stored in preview space (y up) because submit() converts; feet are at y = -20 from the neck.
            boxes.add(new Box(class_3532.method_15362(a) * r, -18f + bob + (i % 3) * 2.5f, class_3532.method_15374(a) * r, 1.3f, 1.3f, 1.3f, 0f,
                    i % 2 == 0 ? aura.color() : aura.secondary(), true));
        }
        submit(matrices, queue, layer, GLOW_LIGHT, boxes, 1);
        matrices.method_22909();
    }

    /**
     * Queues the boxes in one custom draw. {@code mirrorX} is -1 for the left
     * wing. Conversion from preview space: y and z flip, and so does the sign of
     * a rotation around z; mirroring x flips it once more.
     */
    private static void submit(class_4587 matrices, class_11659 queue, class_1921 layer, int light, List<Box> boxes, int mirrorX) {
        queue.method_73483(matrices, layer, (entry, vc) -> {
            for (Box b : boxes) {
                int boxLight = b.glow() ? GLOW_LIGHT : light;
                float cx = b.x() * mirrorX;
                float cy = -b.y();
                float cz = -b.z();
                float angle = -b.rz() * mirrorX;
                drawBox(entry, vc, cx, cy, cz, b.w() / 2f, b.h() / 2f, b.d() / 2f, angle, b.color(), boxLight);
            }
        });
    }

    /** Box around (cx, cy, cz) with half sizes, rotated by {@code angle} around z. */
    private static void drawBox(class_4587.class_4665 e, class_4588 vc, float cx, float cy, float cz,
                                float hx, float hy, float hz, float angle, int color, int light) {
        float cos = class_3532.method_15362(angle), sin = class_3532.method_15374(angle);
        float[][] corners = new float[8][3];
        int i = 0;
        for (int sx : new int[]{-1, 1}) for (int sy : new int[]{-1, 1}) for (int sz : new int[]{-1, 1}) {
            float lx = sx * hx, ly = sy * hy;
            corners[i][0] = cx + lx * cos - ly * sin;
            corners[i][1] = cy + lx * sin + ly * cos;
            corners[i][2] = cz + sz * hz;
            i++;
        }
        // corner index = (sx>0)*4 + (sy>0)*2 + (sz>0)
        float nxX = cos, nxY = sin, nyX = -sin, nyY = cos;
        quad(e, vc, color, light, 0, 0, -1, corners[0], corners[4], corners[6], corners[2]); // -z
        quad(e, vc, color, light, 0, 0, 1, corners[5], corners[1], corners[3], corners[7]);  // +z
        quad(e, vc, color, light, -nxX, -nxY, 0, corners[1], corners[0], corners[2], corners[3]); // -x
        quad(e, vc, color, light, nxX, nxY, 0, corners[4], corners[5], corners[7], corners[6]);   // +x
        quad(e, vc, color, light, -nyX, -nyY, 0, corners[1], corners[5], corners[4], corners[0]); // -y
        quad(e, vc, color, light, nyX, nyY, 0, corners[2], corners[6], corners[7], corners[3]);   // +y
    }

    private static void quad(class_4587.class_4665 e, class_4588 vc, int color, int light, float nx, float ny, float nz,
                             float[] a, float[] b, float[] c, float[] d) {
        vertex(e, vc, color, light, nx, ny, nz, a, 0, 0);
        vertex(e, vc, color, light, nx, ny, nz, b, 1, 0);
        vertex(e, vc, color, light, nx, ny, nz, c, 1, 1);
        vertex(e, vc, color, light, nx, ny, nz, d, 0, 1);
    }

    private static void vertex(class_4587.class_4665 e, class_4588 vc, int color, int light, float nx, float ny, float nz,
                               float[] p, float u, float v) {
        vc.method_56824(e, p[0], p[1], p[2]).method_39415(color).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(light).method_60831(e, nx, ny, nz);
    }
}
