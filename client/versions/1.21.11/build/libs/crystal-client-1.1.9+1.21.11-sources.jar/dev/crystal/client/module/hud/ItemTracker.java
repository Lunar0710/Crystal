package dev.crystal.client.module.hud;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public class ItemTracker extends HudModule {

        // Whatever's in the main hand the moment this is enabled is what gets tracked —
    // re-toggle it while holding something else to track a different item.
    private class_1792 tracked = class_1802.field_8162;

    public ItemTracker() {
        super("ItemTracker", "Pins a chosen item to the HUD to track its inventory count", 4, 100);
    }

    @Override
    public void onEnable() {
        var player = class_310.method_1551().field_1724;
        tracked = player != null ? player.method_6047().method_7909() : class_1802.field_8162;
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null || tracked == class_1802.field_8162) return "Tracking: none";

        int total = 0;
        for (class_1799 stack : player.method_31548().method_67533()) {
            if (stack.method_31574(tracked)) total += stack.method_7947();
        }
        return tracked.method_63680().getString() + ": " + total;
    }
}
