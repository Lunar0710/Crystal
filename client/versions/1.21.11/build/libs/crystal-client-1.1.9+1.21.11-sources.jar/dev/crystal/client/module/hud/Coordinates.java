package dev.crystal.client.module.hud;

import net.minecraft.class_310;

public class Coordinates extends HudModule {

        public Coordinates() {
        super("Coordinates", "Displays player XYZ position", 4, 40);
        setEnabled(true);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return "XYZ: N/A";
        return String.format("XYZ: %.1f / %.1f / %.1f",
                mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
    }
}
