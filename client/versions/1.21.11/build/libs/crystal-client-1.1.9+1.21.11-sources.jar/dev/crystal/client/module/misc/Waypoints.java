package dev.crystal.client.module.misc;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.KeybindSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.hud.HudRenderable;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_3675;

/** No dedicated GUI yet — press the "Add Waypoint" key to drop one at your feet; the HUD line tracks the nearest. */
public class Waypoints extends Module implements HudRenderable {

    public record Waypoint(String name, class_2338 pos) {}

    private final List<Waypoint> waypoints = new ArrayList<>();
    private int addKey = GLFW.GLFW_KEY_UNKNOWN;
    private boolean wasAddPressed = false;

    private int x = 4, y = 280;
    private final Consumer<TickEvent> tickListener = this::onTick;

    public Waypoints() {
        super("Waypoints", "Set and navigate to manually-placed waypoints", ModuleCategory.MISC);
        setEnabled(true);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        if (addKey == GLFW.GLFW_KEY_UNKNOWN || mc.field_1724 == null || mc.field_1755 != null) {
            wasAddPressed = false;
            return;
        }

        boolean pressed = class_3675.method_15987(mc.method_22683(), addKey);
        if (pressed && !wasAddPressed) {
            class_2338 pos = mc.field_1724.method_24515();
            waypoints.add(new Waypoint("Waypoint " + (waypoints.size() + 1), pos));
            mc.field_1724.method_7353(net.minecraft.class_2561.method_43470(
                    "§bWaypoint gesetzt: §f" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()), true);
        }
        wasAddPressed = pressed;
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null || waypoints.isEmpty()) return "Waypoints: none";

        Waypoint nearest = waypoints.get(0);
        double nearestDist = player.method_24515().method_10262(nearest.pos());
        for (Waypoint wp : waypoints) {
            double dist = player.method_24515().method_10262(wp.pos());
            if (dist < nearestDist) {
                nearest = wp;
                nearestDist = dist;
            }
        }
        return String.format("%s: %.0fm", nearest.name(), Math.sqrt(nearestDist));
    }

    @Override
    public int getX() { return x; }
    @Override
    public int getY() { return y; }
    public void setPosition(int x, int y) { this.x = x; this.y = y; }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(new KeybindSetting("Add Waypoint", () -> addKey, v -> addKey = v));
    }
}
