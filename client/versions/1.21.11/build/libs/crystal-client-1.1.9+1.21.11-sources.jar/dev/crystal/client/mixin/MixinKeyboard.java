package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.gui.CrystalClientScreen;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class MixinKeyboard {

    @Shadow private class_310 minecraft;

    @Inject(method = "keyPress", at = @At("HEAD"))
    private void onKey(long window, int action, class_11908 input, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) return;

        int key = input.comp_4795();

        // Right Shift opens Crystal GUI
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && minecraft.field_1755 == null) {
            minecraft.execute(() -> minecraft.method_1507(new dev.crystal.client.gui.HudEditorScreen()));
            return;
        }

        // Only while actually in the world — otherwise every character typed
        // into a text field (Crystal's own menu, chat, sign editing) would also
        // fire whatever module is bound to that key.
        if (minecraft.field_1755 != null) return;

        if (CrystalClient.getInstance() != null) {
            CrystalClient.getInstance().getModuleManager().handleKeybind(key);
        }
    }
}
