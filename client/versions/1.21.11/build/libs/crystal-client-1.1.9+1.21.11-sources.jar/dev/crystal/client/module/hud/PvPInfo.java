package dev.crystal.client.module.hud;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3966;

/** Tracks the last entity swung at (see {@link ComboCounter} for why this is a swing-based approximation, not a server-confirmed hit). */
public class PvPInfo extends HudModule {

        private boolean wasAttackPressed = false;
    private String lastTargetName = null;

    private final Consumer<TickEvent> tickListener = this::onTick;

    public PvPInfo() {
        super("PvPInfo", "Shows combo, last hit and combat stats during a fight", 4, 184);
    }

    @Override
    public void onEnable() {
        lastTargetName = null;
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        boolean pressed = mc.field_1690.field_1886.method_1434();
        boolean justPressed = pressed && !wasAttackPressed;
        wasAttackPressed = pressed;

        if (justPressed && mc.field_1765 instanceof class_3966 hit && hit.method_17782() instanceof class_1309 target) {
            lastTargetName = target.method_5477().getString();
        }
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return "PvP: N/A";

        String you = String.format("You: %.1f HP", mc.field_1724.method_6032());
        return lastTargetName == null ? you : you + " | Last: " + lastTargetName;
    }
}
