package dev.crystal.client.module.hud;

import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Setting;
import java.util.List;
import net.minecraft.class_310;

/** Movement speed in blocks per second, measured from the player's position between refreshes. */
public class SpeedDisplay extends HudModule {

    private boolean horizontalOnly = true;

    private double lastX, lastY, lastZ;
    private long lastAt = 0;
    private double speed = 0;

    public SpeedDisplay() {
        super("SpeedDisplay", "Shows how fast you move in blocks per second", 4, 176);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return "Speed: -";

        long now = System.currentTimeMillis();
        double x = mc.field_1724.method_23317(), y = mc.field_1724.method_23318(), z = mc.field_1724.method_23321();
        if (lastAt != 0 && now > lastAt) {
            double dx = x - lastX, dz = z - lastZ, dy = horizontalOnly ? 0 : y - lastY;
            double measured = Math.sqrt(dx * dx + dy * dy + dz * dz) / ((now - lastAt) / 1000.0);
            // Light smoothing so the number doesn't flicker between refreshes.
            speed = speed * 0.4 + measured * 0.6;
        }
        lastX = x; lastY = y; lastZ = z; lastAt = now;
        return "Speed: " + String.format("%.2f", speed) + " b/s";
    }

    @Override
    protected List<Setting<?>> getExtraSettings() {
        return List.of(new BooleanSetting("Horizontal Only", () -> horizontalOnly, v -> horizontalOnly = v, true));
    }
}
