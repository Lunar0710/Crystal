package dev.crystal.client.module.misc;

import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class PackDisplay extends HudModule {

        public PackDisplay() {
        super("PackDisplay", "Shows the name of your currently active resource pack on screen", ModuleCategory.MISC, 4, 268);
    }

    @Override
    public String getText() {
        var profiles = class_310.method_1551().method_1520().method_14444();
        String names = profiles.stream()
                .filter(p -> !p.method_14463().equals("vanilla"))
                .map(p -> p.method_14457())
                .map(class_2561::getString)
                .reduce((a, b) -> a + ", " + b)
                .orElse(null);
        return "Pack: " + (names == null ? "default" : names);
    }
}
