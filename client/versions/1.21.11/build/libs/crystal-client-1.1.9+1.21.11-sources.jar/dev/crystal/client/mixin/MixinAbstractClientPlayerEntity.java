package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.player.SkinChanger;
import dev.crystal.client.util.CosmeticCapeLoader;
import dev.crystal.client.util.SkinFetcher;
import net.minecraft.class_12079;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public class MixinAbstractClientPlayerEntity {

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void onGetSkin(CallbackInfoReturnable<class_8685> cir) {
        if (CrystalClient.getInstance() == null) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || (Object) this != mc.field_1724) return;

        class_8685 current = cir.getReturnValue();
        boolean changed = false;

        SkinChanger module = CrystalClient.getInstance().getModuleManager()
                .getModuleByName("SkinChanger")
                .filter(m -> m.isEnabled())
                .map(m -> (SkinChanger) m)
                .orElse(null);
        if (module != null && !module.getTargetUsername().isEmpty()) {
            class_8685 replacement = SkinFetcher.getOrFetch(module.getTargetUsername());
            if (replacement != null) {
                // Swap the skin and arm model only; the player's own cape and
                // elytra texture used to vanish along with the old skin.
                current = class_8685.method_74884(replacement.comp_1626(), current.comp_1627(), current.comp_1628(), replacement.comp_1629());
                changed = true;
            }
        }

        // Cosmetics-page cape is independent of SkinChanger — applies whether
        // or not the skin itself was also swapped above.
        class_12079.class_12081 cape = CosmeticCapeLoader.getEquippedCape();
        if (cape != null) {
            current = class_8685.method_74884(current.comp_1626(), cape, current.comp_1628(), current.comp_1629());
            changed = true;
        }

        if (changed) cir.setReturnValue(current);
    }
}
