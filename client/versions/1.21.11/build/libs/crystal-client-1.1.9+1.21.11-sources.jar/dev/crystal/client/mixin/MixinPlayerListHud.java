package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.gui.GuiRender;
import dev.crystal.client.module.misc.TabEditor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_640;

@Mixin(class_355.class)
public class MixinPlayerListHud {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 context, int screenWidth, class_269 scoreboard, class_266 objective, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null) return;

        TabEditor module = CrystalClient.getInstance().getModuleManager().getModuleByName("TabEditor")
                .filter(m -> m.isEnabled())
                .map(m -> (TabEditor) m)
                .orElse(null);
        if (module == null) return;

        ci.cancel();

        class_310 mc = class_310.method_1551();
        if (mc.method_1562() == null) return;

        class_355 self = (class_355) (Object) this;

        List<class_640> entries = new ArrayList<>(mc.method_1562().method_45732());
        entries.sort(Comparator.comparing(e -> e.method_2966().name(), String.CASE_INSENSITIVE_ORDER));

        int columnWidth = module.getColumnWidth();
        int columns = Math.max(1, Math.min(4, screenWidth / (columnWidth + 10)));
        int rows = (int) Math.ceil(entries.size() / (double) columns);
        int rowHeight = 10;

        int totalWidth = columns * columnWidth + (columns - 1) * 10;
        int x0 = (screenWidth - totalWidth) / 2;
        int y0 = 10;

        GuiRender.roundedRect(context, x0 - 4, y0 - 4, x0 + totalWidth + 4, y0 + rows * rowHeight + 4, module.getBackgroundColor());

        for (int i = 0; i < entries.size(); i++) {
            class_640 entry = entries.get(i);
            int col = i / rows;
            int row = i % rows;
            int x = x0 + col * (columnWidth + 10);
            int y = y0 + row * rowHeight;

            String name = self.method_1918(entry).getString();
            context.method_25303(mc.field_1772, name, x, y, module.getTextColor());

            if (module.isShowPing()) {
                String ping = entry.method_2959() + "ms";
                int pingWidth = mc.field_1772.method_1727(ping);
                context.method_25303(mc.field_1772, ping, x + columnWidth - pingWidth, y, 0xFF808080);
            }
        }
    }
}
