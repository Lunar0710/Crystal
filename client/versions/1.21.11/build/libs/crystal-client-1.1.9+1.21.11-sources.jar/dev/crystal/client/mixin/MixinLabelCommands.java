package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.render.NameTags;
import net.minecraft.class_11689;
import net.minecraft.class_315;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** NameTags "Background Opacity" for the dark box behind nametags. */
@Mixin(class_11689.class_12050.class)
public class MixinLabelCommands {

    @Redirect(method = "add", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;getBackgroundOpacity(F)F"))
    private float crystal$labelBackground(class_315 options, float fallback) {
        CrystalClient client = CrystalClient.getInstance();
        NameTags module = client == null ? null : client.getModuleManager().getEnabled(NameTags.class);
        return module != null ? module.getBackgroundOpacity() : options.method_19343(fallback);
    }
}
