package dev.crystal.client.module.player;

import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.SliderSetting;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;

/**
 * Warning above the hotbar when a worn armor piece or the held item is close to
 * breaking. Drawn in CrystalHUD.
 */
public class DurabilityWarning extends Module {

    private static final class_1304[] SLOTS = {
            class_1304.field_6173, class_1304.field_6171, class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    private float thresholdPercent = 10f;
    private boolean includeHands = true;

    public DurabilityWarning() {
        super("DurabilityWarning", "Warns above the hotbar when armor or your tool is about to break", ModuleCategory.PLAYER);
        setEnabled(true);
    }

    /** The most worn item under the threshold, or null when everything is fine. */
    public class_1799 findWornItem() {
        var player = class_310.method_1551().field_1724;
        if (player == null) return null;
        class_1799 worst = null;
        float worstFraction = thresholdPercent / 100f;
        for (class_1304 slot : SLOTS) {
            if (!includeHands && (slot == class_1304.field_6173 || slot == class_1304.field_6171)) continue;
            class_1799 stack = player.method_6118(slot);
            if (stack.method_7960() || !stack.method_7963() || stack.method_7936() <= 0) continue;
            float left = 1f - (float) stack.method_7919() / stack.method_7936();
            if (left <= worstFraction) {
                worst = stack;
                worstFraction = left;
            }
        }
        return worst;
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new SliderSetting("Warn Below %", () -> thresholdPercent, v -> thresholdPercent = v, 2f, 50f, 1f, 0),
                new BooleanSetting("Include Held Items", () -> includeHands, v -> includeHands = v, true)
        );
    }
}
