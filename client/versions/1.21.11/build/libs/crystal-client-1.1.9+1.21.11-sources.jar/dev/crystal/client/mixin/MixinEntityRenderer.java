package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.render.NameTags;
import dev.crystal.client.module.render.TeamView;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NameTags health and TeamView markers, added to a player's label as its render state is built. */
@Mixin(class_897.class)
public class MixinEntityRenderer {

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void crystal$decorateLabel(class_1297 entity, class_10017 state, float tickProgress, CallbackInfo ci) {
        if (state.field_53337 == null || !(entity instanceof class_1657 player)) return;
        CrystalClient client = CrystalClient.getInstance();
        if (client == null) return;

        NameTags tags = client.getModuleManager().getEnabled(NameTags.class);
        if (tags != null) state.field_53337 = tags.decorate(state.field_53337, player);
        TeamView team = client.getModuleManager().getEnabled(TeamView.class);
        if (team != null) state.field_53337 = team.decorate(state.field_53337, player);
    }
}
