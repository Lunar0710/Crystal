package dev.crystal.client.module.hud;

import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Setting;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class DirectionHUD extends HudModule {

    // Minecraft yaw: 0°=South, 90°=West, 180°=North, 270°=East — increasing clockwise.
    private static final String[] COMPASS = { "S", "SW", "W", "NW", "N", "NE", "E", "SE" };

        private boolean showDegrees = true;

    public DirectionHUD() {
        super("DirectionHUD", "Displays a compass showing the direction you're facing", 4, 64);
        setEnabled(true);
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null) return "Facing: N/A";

        float yawDeg = class_3532.method_15393(player.method_36454());
        float normalized = yawDeg < 0 ? yawDeg + 360f : yawDeg;
        int index = Math.floorMod(Math.round(normalized / 45f), 8);
        String direction = COMPASS[index];
        return showDegrees ? "Facing: " + direction + " (" + Math.round(normalized) + "°)" : "Facing: " + direction;
    }

    @Override
    protected List<Setting<?>> getExtraSettings() {
        return List.of(new BooleanSetting("Show Degrees", () -> showDegrees, v -> showDegrees = v, true));
    }
}
