package dev.crystal.client.module.movement;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Setting;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_310;

public class Sprint extends Module {

    private boolean omnidirectional = true;
    private boolean requireFood = true;
    private boolean allowInWater = false;
    private final Consumer<TickEvent> tickListener = this::onTick;

    public Sprint() {
        super("Sprint", "Always sprint, even sideways", ModuleCategory.MOVEMENT);
    }

    public boolean isOmnidirectional() { return omnidirectional; }
    public void setOmnidirectional(boolean v) { this.omnidirectional = v; }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        if (mc.field_1724 == null) return;

        var options = mc.field_1690;
        boolean moving = options.field_1894.method_1434() || options.field_1881.method_1434()
                || (omnidirectional && (options.field_1913.method_1434() || options.field_1849.method_1434()));

        boolean waterOk = allowInWater || !mc.field_1724.method_5799();
        boolean foodOk = !requireFood || mc.field_1724.method_7344().method_7586() > 6;

        if (moving && !mc.field_1724.method_5715() && waterOk && foodOk) {
            mc.field_1724.method_5728(true);
        }
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new BooleanSetting("Omnidirectional", () -> omnidirectional, v -> omnidirectional = v, true),
                new BooleanSetting("Require Food", () -> requireFood, v -> requireFood = v, true),
                new BooleanSetting("Allow In Water", () -> allowInWater, v -> allowInWater = v, false)
        );
    }
}
