package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.render.ItemPhysics;
import dev.crystal.client.module.render.Items2D;
import dev.crystal.client.util.ItemGroundState;
import net.minecraft.class_10039;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1542;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Dropped items: 2D Items turns them to face the camera like sprites,
 * ItemPhysics lays them flat once they land. Both stop the up-and-down bob.
 */
@Mixin(class_916.class)
public class MixinItemEntityRenderer {

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V", at = @At("TAIL"))
    private void crystal$rememberGround(class_1542 entity, class_10039 state, float tickProgress, CallbackInfo ci) {
        ((ItemGroundState) state).crystal$setOnGround(entity.method_24828());
    }

    @Redirect(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Mth;sin(D)F"))
    private float crystal$bob(double value) {
        // sin() = -1 makes vanilla's "sin * 0.1 + 0.1" bob offset exactly 0.
        return crystal$items2D() != null || crystal$physics() != null ? -1f : class_3532.method_15374(value);
    }

    @Redirect(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;mulPose(Lorg/joml/Quaternionfc;)V"))
    private void crystal$rotate(class_4587 matrices, Quaternionfc spin, class_10039 state, class_4587 sameMatrices,
                                class_11659 queue, class_12075 camera) {
        ItemPhysics physics = crystal$physics();
        if (physics != null && ((ItemGroundState) state).crystal$isOnGround()) {
            // Lying on the ground: a fixed random turn, then tipped flat.
            matrices.method_22907(class_7833.field_40716.rotation(state.field_53435));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(90f));
            return;
        }
        if (crystal$items2D() != null) {
            matrices.method_22907(camera.field_63081);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(180f));
            return;
        }
        matrices.method_22907(spin);
    }

    @org.spongepowered.asm.mixin.Unique
    private static Items2D crystal$items2D() {
        CrystalClient client = CrystalClient.getInstance();
        return client == null ? null : client.getModuleManager().getEnabled(Items2D.class);
    }

    @org.spongepowered.asm.mixin.Unique
    private static ItemPhysics crystal$physics() {
        CrystalClient client = CrystalClient.getInstance();
        return client == null ? null : client.getModuleManager().getEnabled(ItemPhysics.class);
    }
}
