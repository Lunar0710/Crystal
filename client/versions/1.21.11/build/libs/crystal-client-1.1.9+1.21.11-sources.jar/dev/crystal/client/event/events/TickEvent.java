package dev.crystal.client.event.events;

import net.minecraft.class_310;

public class TickEvent {
    private final class_310 client;

    public TickEvent(class_310 client) {
        this.client = client;
    }

    public class_310 getClient() {
        return client;
    }
}
