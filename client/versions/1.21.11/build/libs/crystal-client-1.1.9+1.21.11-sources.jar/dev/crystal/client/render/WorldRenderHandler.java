package dev.crystal.client.render;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.hud.TNTCountdown;
import dev.crystal.client.module.render.BlockOutline;
import dev.crystal.client.module.render.ChunkBorders;
import dev.crystal.client.module.render.Hitbox;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_12074;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9974;
import org.joml.Quaternionf;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Central hook for everything Crystal draws in world space (block outline,
 * hitboxes, chunk borders).
 *
 * All of it goes through {@link class_9974#method_62296} on the vanilla
 * line layer — the same call vanilla's own block outline uses — so the lines
 * respect depth, line width and the active render pipeline exactly like
 * vanilla geometry does.
 */
public final class WorldRenderHandler {

    private WorldRenderHandler() {}

    public static void register() {
        // Returning false cancels vanilla's own outline so ours replaces it
        // rather than double-drawing on top of it.
        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((context, outlineState) -> {
            BlockOutline module = module("BlockOutline", BlockOutline.class);
            if (module == null || outlineState == null) return true;

            drawBlockOutline(context, outlineState, module);
            return false;
        });

        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            Hitbox hitbox = module("Hitbox", Hitbox.class);
            if (hitbox != null) drawHitboxes(context, hitbox);

            ChunkBorders borders = module("ChunkBorders", ChunkBorders.class);
            if (borders != null) drawChunkBorders(context, borders);

            dev.crystal.client.module.render.WorldEditCUI worldEdit = module("WorldEditCUI", dev.crystal.client.module.render.WorldEditCUI.class);
            if (worldEdit != null) worldEdit.render(context.matrices(), context.consumers().method_73477(class_12249.method_76015()), cameraPos(context));

            TNTCountdown tnt = module("TNTCountdown", TNTCountdown.class);
            if (tnt != null) drawTntCountdowns(context, tnt);
        });
    }

    /** The enabled instance of a module, or null when it's off — every draw path starts here. */
    private static <T extends Module> T module(String name, Class<T> type) {
        if (CrystalClient.getInstance() == null) return null;
        return CrystalClient.getInstance().getModuleManager().getEnabled(type);
    }

    private static void drawBlockOutline(WorldRenderContext context, class_12074 state, BlockOutline module) {
        class_265 shape = state.comp_4935();
        if (shape.method_1110()) return;

        class_2338 pos = state.comp_4932();
        class_243 camera = cameraPos(context);
        class_4588 consumer = context.consumers().method_73477(class_12249.method_76015());

        class_9974.method_62296(
                context.matrices(), consumer, shape,
                pos.method_10263() - camera.field_1352, pos.method_10264() - camera.field_1351, pos.method_10260() - camera.field_1350,
                module.getOutlineColor(), module.getLineWidth());
    }

    private static void drawHitboxes(WorldRenderContext context, Hitbox module) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_243 camera = cameraPos(context);
        class_4588 consumer = context.consumers().method_73477(class_12249.method_76015());
        double maxDistanceSq = module.getRange() * module.getRange();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724 && !module.isShowOwnHitbox()) continue;
            if (module.isPlayersOnly() && !(entity instanceof class_1657)) continue;
            if (entity.method_5858(mc.field_1724) > maxDistanceSq) continue;

            class_238 box = entity.method_5829();
            class_9974.method_62296(
                    context.matrices(), consumer, hitboxShape(box.method_17939(), box.method_17940(), box.method_17941()),
                    box.field_1323 - camera.field_1352, box.field_1322 - camera.field_1351, box.field_1321 - camera.field_1350,
                    module.colorFor(entity), module.getLineWidth());
        }
    }

    /**
     * Hitbox outlines by size. Nearly every entity shares one of a few box sizes,
     * so reusing the shape avoids building a VoxelShape per entity per frame,
     * which added up on busy servers. Sizes are keyed at 1/1000 block.
     */
    private static final Map<Long, class_265> HITBOX_SHAPES = new HashMap<>();

    private static class_265 hitboxShape(double x, double y, double z) {
        long key = (Math.round(x * 1000) << 42) ^ (Math.round(y * 1000) << 21) ^ Math.round(z * 1000);
        class_265 shape = HITBOX_SHAPES.get(key);
        if (shape == null) {
            // Sizes change continuously for a few entities (e.g. growing slimes); keep the cache bounded.
            if (HITBOX_SHAPES.size() > 256) HITBOX_SHAPES.clear();
            shape = class_259.method_1081(0, 0, 0, x, y, z);
            HITBOX_SHAPES.put(key, shape);
        }
        return shape;
    }

    private static void drawChunkBorders(WorldRenderContext context, ChunkBorders module) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        class_243 camera = cameraPos(context);
        class_4588 consumer = context.consumers().method_73477(class_12249.method_76015());

        // The 16x16 column the player is standing in, from world bottom to top.
        int chunkX = mc.field_1724.method_24515().method_10263() >> 4;
        int chunkZ = mc.field_1724.method_24515().method_10260() >> 4;
        double minX = chunkX << 4;
        double minZ = chunkZ << 4;
        double minY = mc.field_1687 != null ? mc.field_1687.method_31607() : -64;
        double maxY = minY + (mc.field_1687 != null ? mc.field_1687.method_31605() : 384);

        class_265 column = class_259.method_1081(0, 0, 0, 16, maxY - minY, 16);
        class_9974.method_62296(
                context.matrices(), consumer, column,
                minX - camera.field_1352, minY - camera.field_1351, minZ - camera.field_1350,
                module.getBorderColor(), module.getLineWidth());
    }

    /**
     * Billboarded text above each primed TNT entity — same technique vanilla
     * uses for entity nametags: rotate the text to face the camera using the
     * camera's own orientation quaternion, then draw through the "see through"
     * text layer so it isn't hidden behind blocks (nametags do the same).
     */
    private static void drawTntCountdowns(WorldRenderContext context, TNTCountdown module) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;

        class_243 camera = cameraPos(context);
        Quaternionf cameraOrientation = context.worldState().field_63082.field_63081;
        class_327 textRenderer = mc.field_1772;
        class_4597 consumers = context.consumers();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1541 tnt)) continue;

            // Tenths of a second; String.format per TNT per frame was needlessly heavy.
            int tenths = tnt.method_6969() / 2;
            String label = (tenths / 10) + "." + (tenths % 10) + "s";
            int textWidth = textRenderer.method_1727(label);

            class_4587 matrices = context.matrices();
            matrices.method_22903();
            matrices.method_22904(
                    entity.method_23317() - camera.field_1352,
                    entity.method_23318() - camera.field_1351 + entity.method_17682() + 0.5,
                    entity.method_23321() - camera.field_1350);
            matrices.method_22907(cameraOrientation);
            matrices.method_22905(-0.025f * module.getScale(), -0.025f * module.getScale(), 0.025f * module.getScale());

            textRenderer.method_27521(label, -textWidth / 2f, 0, module.getColor(), false,
                    matrices.method_23760().method_23761(), consumers, class_327.class_6415.field_33994, 0, 0xF000F0);

            matrices.method_22909();
        }
    }

    private static class_243 cameraPos(WorldRenderContext context) {
        return context.worldState().field_63082.field_63078;
    }
}
