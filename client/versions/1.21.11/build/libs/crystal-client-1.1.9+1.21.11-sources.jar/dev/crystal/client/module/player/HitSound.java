package dev.crystal.client.module.player;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.EnumSetting;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.SliderSetting;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3966;

/** Same swing-based approximation as ComboCounter — Minecraft doesn't tell the client when a hit actually connects. */
public class HitSound extends Module {

    private static final String SOUND_BOW = "Bow Hit";
    private static final String SOUND_ANVIL = "Anvil";
    private static final String SOUND_EXP = "Experience";
    private static final String SOUND_KNOCKBACK = "Knockback";

    private String sound = SOUND_KNOCKBACK;
    private float volume = 40f;
    private float pitch = 1.6f;
    private boolean wasAttackPressed = false;
    private final Consumer<TickEvent> tickListener = this::onTick;

    public HitSound() {
        super("HitSound", "Plays a distinct sound when you land a hit", ModuleCategory.PLAYER);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        if (mc.field_1724 == null) return;

        boolean pressed = mc.field_1690.field_1886.method_1434();
        boolean justPressed = pressed && !wasAttackPressed;
        wasAttackPressed = pressed;

        if (justPressed && mc.field_1765 instanceof class_3966 hit && hit.method_17782() instanceof class_1309) {
            mc.field_1724.method_5783(selectedSound(), volume / 100f, pitch);
        }
    }

    private net.minecraft.class_3414 selectedSound() {
        return switch (sound) {
            case SOUND_BOW -> class_3417.field_15224;
            case SOUND_ANVIL -> class_3417.field_14833;
            case SOUND_EXP -> class_3417.field_14627;
            default -> class_3417.field_14999;
        };
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new EnumSetting("Sound", () -> sound, v -> sound = v, List.of(SOUND_KNOCKBACK, SOUND_BOW, SOUND_ANVIL, SOUND_EXP)),
                new SliderSetting("Volume", () -> volume, v -> volume = v, 5f, 100f, 5f, 0),
                new SliderSetting("Pitch", () -> pitch, v -> pitch = v, 0.5f, 2f, 0.1f, 1)
        );
    }
}
