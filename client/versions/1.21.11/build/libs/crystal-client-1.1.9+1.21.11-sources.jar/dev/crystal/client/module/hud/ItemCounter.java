package dev.crystal.client.module.hud;

import net.minecraft.class_1799;
import net.minecraft.class_310;

public class ItemCounter extends HudModule {

        public ItemCounter() {
        super("ItemCounter", "Shows the total count of the item in your held stack across your inventory", 4, 88);
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null) return "Held: N/A";

        class_1799 held = player.method_6047();
        if (held.method_7960()) return "Held: nothing";

        int total = 0;
        for (class_1799 stack : player.method_31548().method_67533()) {
            if (class_1799.method_31577(stack, held)) total += stack.method_7947();
        }
        return held.method_7909().method_63680().getString() + ": " + total;
    }
}
