package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.render.BackgroundFps;
import net.minecraft.class_310;
import net.minecraft.class_9919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lowers vanilla's frame limit while the window is unfocused (see {@link BackgroundFps}). */
@Mixin(class_9919.class)
public class MixinInactivityFpsLimiter {

    @Inject(method = "getFramerateLimit", at = @At("RETURN"), cancellable = true)
    private void crystal$backgroundLimit(CallbackInfoReturnable<Integer> cir) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_1569() || CrystalClient.getInstance() == null) return;

        Module module = CrystalClient.getInstance().getModuleManager().getModuleByName("BackgroundFps").orElse(null);
        if (!(module instanceof BackgroundFps background) || !module.isEnabled()) return;

        cir.setReturnValue(Math.min(cir.getReturnValueI(), background.getFps()));
    }
}
