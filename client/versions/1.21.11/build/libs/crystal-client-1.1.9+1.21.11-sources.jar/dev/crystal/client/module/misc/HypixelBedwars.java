package dev.crystal.client.module.misc;

import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

/**
 * Reads whatever the server's own sidebar scoreboard sends — Hypixel doesn't
 * have a public live-game API, so this is a text summary of the real
 * scoreboard, not a guaranteed structured Bed Wars API. Only shows anything
 * while connected to Hypixel and the sidebar title looks like a Bed Wars game.
 */
public class HypixelBedwars extends HudModule {

    public HypixelBedwars() {
        super("HypixelBedwars", "Bed Wars specific overlays (bed status, team upgrades) on Hypixel", 4, 328);
        setEnabled(true);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.method_1558() == null || !mc.method_1558().field_3761.toLowerCase().contains("hypixel")) {
            return "";
        }
        if (mc.field_1724 == null || mc.method_1562() == null) return "";

        class_269 scoreboard = mc.method_1562().method_55823();
        class_266 objective = scoreboard.method_1189(class_8646.field_45157);
        if (objective == null) return "";

        String title = objective.method_1114().getString();
        if (!title.toUpperCase().contains("BED WARS") && !title.toUpperCase().contains("BEDWARS")) return "";

        int bedsStanding = 0;
        int bedsDestroyed = 0;
        for (class_9011 entry : scoreboard.method_1184(objective)) {
            if (entry.method_55385()) continue;
            String line = entry.method_55387().getString();
            // Hypixel marks a broken bed with a red X-style icon in the sidebar line.
            if (line.contains("❤") || line.toLowerCase().contains("bed")) {
                if (line.contains("✗") || line.contains("X ")) bedsDestroyed++;
                else bedsStanding++;
            }
        }

        if (bedsStanding == 0 && bedsDestroyed == 0) return "Bed Wars";
        return String.format("Beds: %d standing, %d destroyed", bedsStanding, bedsDestroyed);
    }
}
