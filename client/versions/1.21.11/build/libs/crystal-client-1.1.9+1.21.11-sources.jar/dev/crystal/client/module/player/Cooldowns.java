package dev.crystal.client.module.player;

import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class Cooldowns extends HudModule {

        public Cooldowns() {
        super("Cooldowns", "Displays attack/item-use cooldown indicators", ModuleCategory.PLAYER, 4, 232);
        setEnabled(true);
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null) return "";

        // Attack cooldown (weapon "charge") only matters while it's not already full.
        float attackProgress = player.method_7261(0f);
        String attack = attackProgress < 1f ? "Attack: " + Math.round(attackProgress * 100) + "%" : null;

        class_1799 held = player.method_6047();
        String item = null;
        if (player.method_7357().method_7904(held)) {
            float progress = 1f - player.method_7357().method_7905(held, 0f);
            item = held.method_7909().method_63680().getString() + ": " + Math.round(progress * 100) + "%";
        }

        if (attack == null && item == null) return "";
        if (attack != null && item != null) return attack + " | " + item;
        return attack != null ? attack : item;
    }
}
