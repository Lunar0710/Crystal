package dev.crystal.client.module.hud;

import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public class TargetHUD extends HudModule {

        public TargetHUD() {
        super("TargetHUD", "Shows health and info of your current target", 4, 160);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (!(mc.field_1765 instanceof class_3966 hit) || !(hit.method_17782() instanceof class_1309 target)) {
            return "Target: none";
        }
        return String.format("Target: %s (%.1f/%.1f HP)",
                target.method_5477().getString(), target.method_6032(), target.method_6063());
    }
}
