package dev.crystal.client.module.player;

import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_1293;
import net.minecraft.class_310;

public class PotionEffectsDisplay extends HudModule {

        public PotionEffectsDisplay() {
        super("PotionEffects", "Restyled active potion effect icons", ModuleCategory.PLAYER, 4, 244);
        setEnabled(true);
    }

    @Override
    public String getText() {
        var player = class_310.method_1551().field_1724;
        if (player == null || player.method_6026().isEmpty()) return "";

        StringBuilder sb = new StringBuilder();
        for (class_1293 effect : player.method_6026()) {
            if (sb.length() > 0) sb.append(" | ");
            int amplifier = effect.method_5578() + 1;
            int seconds = effect.method_5584() / 20;
            sb.append(effect.method_5579().comp_349().method_5560().getString())
              .append(' ').append(amplifier)
              .append(" (").append(seconds / 60).append(':').append(String.format("%02d", seconds % 60)).append(')');
        }
        return sb.toString();
    }
}
