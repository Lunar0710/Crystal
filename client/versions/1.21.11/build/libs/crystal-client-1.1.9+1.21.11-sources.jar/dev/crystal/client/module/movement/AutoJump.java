package dev.crystal.client.module.movement;

import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import net.minecraft.class_310;

/** Thin wrapper around vanilla's own Auto Jump accessibility option — restores it on disable so it doesn't stay stuck on. */
public class AutoJump extends Module {

    private boolean previousValue;

    public AutoJump() {
        super("AutoJump", "Automatically jumps when walking into a block", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        var option = class_310.method_1551().field_1690.method_42423();
        previousValue = option.method_41753();
        option.method_41748(true);
    }

    @Override
    public void onDisable() {
        class_310.method_1551().field_1690.method_42423().method_41748(previousValue);
    }
}
