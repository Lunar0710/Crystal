package dev.crystal.client.util;

import dev.crystal.client.CrystalClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_3222;
import net.minecraft.class_5498;

/**
 * Automated in-world check, used only by launcher/scripts/smoke-world.cjs.
 * Active solely when the JVM is started with -Dcrystal.smoke.screenshot; a
 * normal launch never sets it, so none of this runs for players.
 *
 * Once a singleplayer world is loaded it gives the player some damaged armor
 * (for the Armor HUD), switches to the front camera (to see cosmetics), takes
 * a screenshot and quits, logging a marker the script waits for.
 */
public final class SmokeTest {

    private static final String PROPERTY = "crystal.smoke.screenshot";
    private static int worldTicks = 0;

    private SmokeTest() {}

    public static void registerIfRequested() {
        String name = System.getProperty(PROPERTY);
        if (name == null || name.isBlank()) return;
        CrystalClient.LOGGER.info("[Crystal] Smoke test active, screenshot: {}", name);
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client, name));
    }

    private static void tick(class_310 mc, String screenshotName) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        worldTicks++;

        if (worldTicks == 40) {
            mc.field_1690.method_31043(class_5498.field_26666);
            mc.field_1724.method_36457(10f);
            var server = mc.method_1576();
            if (server != null) {
                var uuid = mc.field_1724.method_5667();
                server.execute(() -> {
                    class_3222 sp = server.method_3760().method_14602(uuid);
                    if (sp == null) return;
                    sp.method_51469().method_29199(6000);
                    // No helmet, so hat and mask cosmetics stay visible in the screenshot.
                    equip(sp, class_1304.field_6174, new class_1799(class_1802.field_8058), 0.5f);
                    equip(sp, class_1304.field_6172, new class_1799(class_1802.field_8396), 0.8f);
                    equip(sp, class_1304.field_6166, new class_1799(class_1802.field_8753), 0.3f);
                    equip(sp, class_1304.field_6173, new class_1799(class_1802.field_22022), 0.2f);
                });
            }
        }

        if (worldTicks == 160) {
            class_318.method_22690(mc.field_1697, screenshotName, mc.method_1522(), 1,
                    msg -> CrystalClient.LOGGER.info("[Crystal] Smoke screenshot: {}", msg.getString()));
        }

        // The Right Shift menu: module grid, then a settings page.
        String base = screenshotName.endsWith(".png") ? screenshotName.substring(0, screenshotName.length() - 4) : screenshotName;
        if (worldTicks == 170) mc.method_1507(new dev.crystal.client.gui.HudEditorScreen());
        if (worldTicks == 188) {
            class_318.method_22690(mc.field_1697, base + "-editor.png", mc.method_1522(), 1,
                    msg -> CrystalClient.LOGGER.info("[Crystal] Smoke screenshot: {}", msg.getString()));
        }
        if (worldTicks == 192) mc.method_1507(new dev.crystal.client.gui.CrystalClientScreen());
        if (worldTicks == 210) {
            class_318.method_22690(mc.field_1697, base + "-menu.png", mc.method_1522(), 1,
                    msg -> CrystalClient.LOGGER.info("[Crystal] Smoke screenshot: {}", msg.getString()));
        }
        if (worldTicks == 214 && mc.field_1755 instanceof dev.crystal.client.gui.CrystalClientScreen menu) {
            menu.openSettingsForTest("ArmorDisplay");
        }
        if (worldTicks == 232) {
            class_318.method_22690(mc.field_1697, base + "-settings.png", mc.method_1522(), 1,
                    msg -> CrystalClient.LOGGER.info("[Crystal] Smoke screenshot: {}", msg.getString()));
        }

        // The crosshair pixel editor, with a few pixels painted.
        if (worldTicks == 236) {
            CrystalClient.getInstance().getModuleManager().getModuleByName("Crosshair")
                    .filter(m -> m instanceof dev.crystal.client.module.render.Crosshair)
                    .map(m -> (dev.crystal.client.module.render.Crosshair) m)
                    .ifPresent(c -> mc.method_1507(new dev.crystal.client.gui.CrosshairEditorScreen(c)));
        }
        if (worldTicks == 254) {
            class_318.method_22690(mc.field_1697, base + "-crosshair.png", mc.method_1522(), 1,
                    msg -> CrystalClient.LOGGER.info("[Crystal] Smoke screenshot: {}", msg.getString()));
        }

        // Back view for wings, backpack and the cape.
        if (worldTicks == 260) {
            mc.method_1507(null);
            mc.field_1690.method_31043(class_5498.field_26665);
        }
        if (worldTicks == 285) {
            class_318.method_22690(mc.field_1697, base + "-back.png", mc.method_1522(), 1,
                    msg -> CrystalClient.LOGGER.info("[Crystal] Smoke screenshot: {}", msg.getString()));
        }

        if (worldTicks == 310) {
            CrystalClient.LOGGER.info("CRYSTAL_SMOKE_WORLD_DONE");
            mc.method_1592();
        }
    }

    /** Equips the item with the given fraction of its durability used up. */
    private static void equip(class_3222 player, class_1304 slot, class_1799 stack, float wear) {
        if (stack.method_7963()) stack.method_7974(Math.round(stack.method_7936() * wear));
        player.method_5673(slot, stack);
    }
}
