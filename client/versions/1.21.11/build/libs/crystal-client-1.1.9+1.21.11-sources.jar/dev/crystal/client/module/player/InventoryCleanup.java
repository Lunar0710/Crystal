package dev.crystal.client.module.player;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.KeybindSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_7923;

/**
 * Sorts the main inventory + hotbar (slots 9–44 of the player's own screen
 * handler — armor, offhand and the crafting grid are left alone) by item type,
 * using the exact same {@link class_1703#method_7593} entry point the
 * vanilla inventory screen itself uses for every click. That method already
 * handles the server-sync packet correctly, so this never has to construct
 * one by hand or guess at how the newer stack-hash reconciliation works.
 *
 * Each pair is swapped with three PICKUP clicks (pick up A, click B swaps
 * cursor/B, click A places what was in B) — the same trick real sort mods
 * use — so this reorders stacks in place rather than merging partial ones:
 * real and safe, just not a full "combine everything" sort.
 */
public class InventoryCleanup extends Module {

    private static final int INVENTORY_START = 9;
    private static final int HOTBAR_END = 45; // exclusive

    private int sortKey = GLFW.GLFW_KEY_UNKNOWN;
    private boolean wasPressed = false;

    private final Consumer<TickEvent> tickListener = this::onTick;

    public InventoryCleanup() {
        super("InventoryCleanup", "Sorts your main inventory and hotbar by item type on a keypress", ModuleCategory.PLAYER);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        if (sortKey == GLFW.GLFW_KEY_UNKNOWN || mc.field_1724 == null || mc.field_1755 != null) {
            wasPressed = false;
            return;
        }

        boolean pressed = class_3675.method_15987(mc.method_22683(), sortKey);
        if (pressed && !wasPressed) sort(mc);
        wasPressed = pressed;
    }

    private void sort(class_310 mc) {
        class_1703 handler = mc.field_1724.field_7498;

        List<Integer> indices = new ArrayList<>();
        for (int i = INVENTORY_START; i < HOTBAR_END; i++) indices.add(i);

        List<Integer> sortedOrder = new ArrayList<>(indices);
        sortedOrder.sort(Comparator.comparing((Integer slot) -> sortKeyFor(handler.method_7611(slot).method_7677())));

        // Cycle-decomposition swap sort: every operation is a strict two-way
        // exchange, so nothing can ever be duplicated or lost even if this
        // were somehow interrupted partway through.
        for (int i = 0; i < indices.size(); i++) {
            int currentSlot = indices.get(i);
            int wantSlot = sortedOrder.get(i);
            if (currentSlot == wantSlot) continue;

            class_1799 currentStack = handler.method_7611(currentSlot).method_7677();
            class_1799 wantedStack = handler.method_7611(wantSlot).method_7677();
            if (class_1799.method_31577(currentStack, wantedStack)) continue;

            handler.method_7593(currentSlot, 0, class_1713.field_7790, mc.field_1724);
            handler.method_7593(wantSlot, 0, class_1713.field_7790, mc.field_1724);
            handler.method_7593(currentSlot, 0, class_1713.field_7790, mc.field_1724);
        }
    }

    /** Empty slots sort last; everything else by its registry id so identical items land next to each other. */
    private String sortKeyFor(class_1799 stack) {
        if (stack.method_7960()) return "￿";
        return class_7923.field_41178.method_10221(stack.method_7909() == null ? class_1802.field_8162 : stack.method_7909()).toString();
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(new KeybindSetting("Sort Key", () -> sortKey, v -> sortKey = v));
    }
}
