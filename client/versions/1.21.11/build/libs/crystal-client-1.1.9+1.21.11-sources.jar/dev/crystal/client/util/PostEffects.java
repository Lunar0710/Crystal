package dev.crystal.client.util;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.mixin.GameRendererAccessor;
import dev.crystal.client.module.render.ColorSaturation;
import dev.crystal.client.module.render.MotionBlur;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Minecraft runs one post effect at a time, so Crystal's world effects are
 * chosen here together: colour grading, motion blur, or both chained in one
 * pipeline. Checked every tick, because vanilla drops the post effect when the
 * camera entity changes (joining a world, respawning). A vanilla effect that is
 * active (like the creeper spectator view) is left alone.
 */
public final class PostEffects {

    public static final class_2960 COLOR_GRADE = class_2960.method_60655(CrystalClient.MOD_ID, "color_grade");
    public static final class_2960 MOTION_BLUR = class_2960.method_60655(CrystalClient.MOD_ID, "motion_blur");
    public static final class_2960 BOTH = class_2960.method_60655(CrystalClient.MOD_ID, "color_grade_motion_blur");

    private PostEffects() {}

    public static void register() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, e -> tick(e.getClient()));
    }

    private static void tick(class_310 mc) {
        if (mc.field_1773 == null || mc.field_1687 == null) return;
        var modules = CrystalClient.getInstance().getModuleManager();
        boolean grade = modules.getEnabled(ColorSaturation.class) != null;
        boolean blur = modules.getEnabled(MotionBlur.class) != null;
        class_2960 wanted = grade && blur ? BOTH : grade ? COLOR_GRADE : blur ? MOTION_BLUR : null;

        class_2960 current = mc.field_1773.method_62906();
        boolean currentIsOurs = current != null && current.method_12836().equals(CrystalClient.MOD_ID);
        if (current != null && !currentIsOurs) return;
        if (wanted == null) {
            if (currentIsOurs) mc.field_1773.method_62905();
        } else if (!wanted.equals(current)) {
            ((GameRendererAccessor) mc.field_1773).crystal$setPostProcessor(wanted);
        }
    }
}
