package dev.crystal.client.module.misc;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.KeybindSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.TextSetting;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class AutoTextHotkey extends Module {

    private int hotkey = GLFW.GLFW_KEY_UNKNOWN;
    private String message = "";
    private boolean wasPressed = false;

    private final Consumer<TickEvent> tickListener = this::onTick;

    public AutoTextHotkey() {
        super("AutoTextHotkey", "Binds a key to send a preset chat message", ModuleCategory.MISC);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        if (hotkey == GLFW.GLFW_KEY_UNKNOWN || message.isBlank() || mc.field_1724 == null
                || mc.field_1755 != null || mc.method_1562() == null) {
            wasPressed = false;
            return;
        }

        boolean pressed = class_3675.method_15987(mc.method_22683(), hotkey);
        if (pressed && !wasPressed) {
            if (message.startsWith("/")) {
                mc.method_1562().method_45730(message.substring(1));
            } else {
                mc.method_1562().method_45729(message);
            }
        }
        wasPressed = pressed;
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new KeybindSetting("Hotkey", () -> hotkey, v -> hotkey = v),
                new TextSetting("Message", () -> message, v -> message = v, "", 256)
        );
    }
}
