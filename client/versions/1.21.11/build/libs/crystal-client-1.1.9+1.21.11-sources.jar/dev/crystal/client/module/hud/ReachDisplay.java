package dev.crystal.client.module.hud;

import net.minecraft.class_310;
import net.minecraft.class_3966;

public class ReachDisplay extends HudModule {

        public ReachDisplay() {
        super("ReachDisplay", "Displays your distance to your current combat target — informational only", 4, 148);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || !(mc.field_1765 instanceof class_3966 hit)) return "Reach: -";

        double distance = mc.field_1724.method_5739(hit.method_17782());
        return String.format("Reach: %.2f", distance);
    }
}
