package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.movement.Freelook;
import dev.crystal.client.module.movement.Snaplook;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Freelook and Snaplook change where the camera looks by replacing the yaw and
 * pitch that Camera.update() reads from the player, rather than overwriting
 * the yaw/pitch fields afterwards.
 *
 * The old TAIL approach only changed those two float fields. Rendering uses the
 * rotation quaternion and direction vectors that setRotation() derives, and the
 * third-person camera position is computed from them too, so the view never
 * actually turned. Feeding the values in before setRotation() runs keeps all
 * of that consistent, including the orbit in third person.
 */
@Mixin(class_4184.class)
public class MixinCamera {

    @Redirect(method = "setup", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewYRot(F)F"))
    private float crystal$cameraYaw(class_1297 entity, float tickDelta) {
        float yaw = entity.method_5705(tickDelta);
        if (!isLocalPlayer(entity)) return yaw;

        Freelook freelook = freelook();
        if (freelook != null) return freelook.getCameraYaw();

        Snaplook snaplook = snaplook();
        return snaplook != null ? snaplook.snap(yaw) : yaw;
    }

    @Redirect(method = "setup", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewXRot(F)F"))
    private float crystal$cameraPitch(class_1297 entity, float tickDelta) {
        float pitch = entity.method_5695(tickDelta);
        if (!isLocalPlayer(entity)) return pitch;

        Freelook freelook = freelook();
        return freelook != null ? freelook.getCameraPitch() : pitch;
    }

    private static boolean isLocalPlayer(class_1297 entity) {
        return CrystalClient.getInstance() != null && entity == class_310.method_1551().field_1724;
    }

    private static Freelook freelook() {
        return CrystalClient.getInstance().getModuleManager().getModuleByName("Freelook")
                .filter(m -> m.isEnabled() && ((Freelook) m).isActive())
                .map(m -> (Freelook) m)
                .orElse(null);
    }

    private static Snaplook snaplook() {
        return CrystalClient.getInstance().getModuleManager().getModuleByName("Snaplook")
                .filter(m -> m.isEnabled() && ((Snaplook) m).isActive())
                .map(m -> (Snaplook) m)
                .orElse(null);
    }
}
