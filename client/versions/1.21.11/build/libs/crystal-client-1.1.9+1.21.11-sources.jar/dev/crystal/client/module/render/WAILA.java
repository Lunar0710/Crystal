package dev.crystal.client.module.render;

import dev.crystal.client.module.hud.HudModule;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2248;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/** "What Am I Looking At" — a HUD line naming whatever's under the crosshair. */
public class WAILA extends HudModule {

    public WAILA() {
        super("WAILA", "\"What Am I Looking At\" — shows the name of the block/entity under your crosshair", 4, 304);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1765 instanceof class_3966 hit) {
            class_1297 entity = hit.method_17782();
            if (entity instanceof class_1309 living) {
                return String.format("%s (%.1f/%.1f HP)", entity.method_5477().getString(), living.method_6032(), living.method_6063());
            }
            return entity.method_5477().getString();
        }
        if (mc.field_1765 instanceof class_3965 hit && mc.field_1687 != null) {
            class_2248 block = mc.field_1687.method_8320(hit.method_17777()).method_26204();
            return block.method_9518().getString();
        }
        return "";
    }
}
