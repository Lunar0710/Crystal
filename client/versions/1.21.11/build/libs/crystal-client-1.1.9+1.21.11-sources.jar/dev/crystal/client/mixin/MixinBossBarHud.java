package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.gui.GuiRender;
import dev.crystal.client.module.hud.BossBar;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_332;
import net.minecraft.class_337;
import net.minecraft.class_345;

@Mixin(class_337.class)
public class MixinBossBarHud {

    @Shadow @Final Map<UUID, class_345> events;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 context, CallbackInfo ci) {
        if (CrystalClient.getInstance() == null || events.isEmpty()) return;

        BossBar module = CrystalClient.getInstance().getModuleManager().getModuleByName("BossBar")
                .filter(m -> m.isEnabled())
                .map(m -> (BossBar) m)
                .orElse(null);
        if (module == null) return;

        ci.cancel();

        var mc = net.minecraft.class_310.method_1551();
        int width = context.method_51421();
        int barWidth = 200;
        int y = 12;

        for (class_345 bar : events.values()) {
            int x = width / 2 - barWidth / 2;

            GuiRender.roundedRect(context, x, y, x + barWidth, y + 8, module.getBackgroundColor());
            int filled = Math.round(barWidth * Math.max(0f, Math.min(1f, bar.method_5412())));
            if (filled > 0) GuiRender.roundedRect(context, x, y, x + filled, y + 8, module.getBarColor());

            String label = bar.method_5414().getString();
            if (module.isShowPercent()) label += " " + Math.round(bar.method_5412() * 100) + "%";
            int textWidth = mc.field_1772.method_1727(label);
            context.method_25303(mc.field_1772, label, width / 2 - textWidth / 2, y - 10, 0xFFFFFFFF);

            y += 20;
        }
    }
}
