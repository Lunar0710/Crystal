package dev.crystal.client.module.render;

import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.ColorSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

/**
 * Marks players by scoreboard team: a coloured dot in front of teammates' and
 * opponents' nametags. Uses only the team data the server already sends (the
 * same that colours names in the tab list), so it shows nothing hidden.
 */
public class TeamView extends Module {

    private int teamColor = 0xFF22C55E;
    private int enemyColor = 0xFFEF4444;
    private boolean markEnemies = true;

    public TeamView() {
        super("TeamView", "Marks teammates and opponents with a coloured dot on their nametag", ModuleCategory.RENDER);
        setEnabled(true);
    }

    public class_2561 decorate(class_2561 name, class_1657 player) {
        var self = class_310.method_1551().field_1724;
        if (self == null || player == self) return name;
        var ownTeam = self.method_5781();
        var theirTeam = player.method_5781();
        if (ownTeam == null || theirTeam == null) return name;

        boolean teammate = ownTeam.method_1206(theirTeam);
        if (!teammate && !markEnemies) return name;
        int color = (teammate ? teamColor : enemyColor) & 0xFFFFFF;
        class_5250 text = class_2561.method_43470("● ").method_27694(s -> s.method_36139(color));
        return text.method_10852(name);
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new ColorSetting("Team Color", () -> teamColor, v -> teamColor = v, 0xFF22C55E),
                new ColorSetting("Enemy Color", () -> enemyColor, v -> enemyColor = v, 0xFFEF4444),
                new BooleanSetting("Mark Enemies", () -> markEnemies, v -> markEnemies = v, true));
    }
}
