package dev.crystal.client.module.hud;

import net.minecraft.class_310;
import net.minecraft.class_640;

public class PingDisplay extends HudModule {

        public PingDisplay() {
        super("Ping", "Displays current server ping", 4, 52);
        setEnabled(true);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.method_1562() == null) return "Ping: N/A";
        class_640 entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        if (entry == null) return "Ping: N/A";
        return "Ping: " + entry.method_2959() + "ms";
    }
}
