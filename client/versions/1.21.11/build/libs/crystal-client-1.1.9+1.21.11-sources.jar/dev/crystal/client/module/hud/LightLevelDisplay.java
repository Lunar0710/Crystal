package dev.crystal.client.module.hud;

import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Setting;
import java.util.List;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_310;

/**
 * Block light at the player's feet. Hostile mobs spawn at block light 0, so
 * this is what matters when lighting up an area; sky light is shown separately.
 */
public class LightLevelDisplay extends HudModule {

    private boolean showSkyLight = false;

    public LightLevelDisplay() {
        super("LightLevel", "Shows the light level where you stand (mobs spawn at block light 0)", 4, 200);
    }

    @Override
    public String getText() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return "Light: -";
        class_2338 pos = mc.field_1724.method_24515();
        int block = mc.field_1687.method_8314(class_1944.field_9282, pos);
        String text = "Light: " + block + (block == 0 ? " (Mobs!)" : "");
        if (showSkyLight) text += "  Sky: " + mc.field_1687.method_8314(class_1944.field_9284, pos);
        return text;
    }

    @Override
    protected List<Setting<?>> getExtraSettings() {
        return List.of(new BooleanSetting("Show Sky Light", () -> showSkyLight, v -> showSkyLight = v, false));
    }
}
