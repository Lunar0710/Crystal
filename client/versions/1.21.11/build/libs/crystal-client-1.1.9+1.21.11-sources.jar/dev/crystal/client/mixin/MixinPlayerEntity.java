package dev.crystal.client.mixin;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.module.player.NickHider;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** NickHider: swaps the local player's own rendered name (tab list, above-head nametag) for a placeholder — everyone else still sees the real name, since this only ever touches our own client-side rendering. */
@Mixin(class_1657.class)
public class MixinPlayerEntity {

    @Inject(method = "getName", at = @At("RETURN"), cancellable = true)
    private void onGetName(CallbackInfoReturnable<class_2561> cir) {
        class_2561 replacement = replacementFor((Object) this);
        if (replacement != null) cir.setReturnValue(replacement);
    }

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void onGetDisplayName(CallbackInfoReturnable<class_2561> cir) {
        class_2561 replacement = replacementFor((Object) this);
        if (replacement != null) cir.setReturnValue(replacement);
    }

    private static class_2561 replacementFor(Object self) {
        if (CrystalClient.getInstance() == null) return null;
        if (self != class_310.method_1551().field_1724) return null;

        NickHider module = CrystalClient.getInstance().getModuleManager().getModuleByName("NickHider")
                .filter(m -> m.isEnabled())
                .map(m -> (NickHider) m)
                .orElse(null);
        return module == null ? null : class_2561.method_43470(module.getPlaceholder());
    }
}
