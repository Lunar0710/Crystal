package dev.crystal.client.module.player;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.event.events.TickEvent;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Setting;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

/** Switches to whichever hotbar slot mines the targeted block fastest, the moment mining starts. */
public class AutoTool extends Module {

    private boolean onlyWhenHoldingTool = false;
    private boolean switchBack = false;
    private int previousSlot = -1;
    private boolean wasAttackPressed = false;
    private final Consumer<TickEvent> tickListener = this::onTick;

    public AutoTool() {
        super("AutoTool", "Automatically switches to the best tool for the block you're mining", ModuleCategory.PLAYER);
    }

    @Override
    public void onEnable() {
        CrystalClient.getInstance().getEventBus().subscribe(TickEvent.class, tickListener);
    }

    @Override
    public void onDisable() {
        CrystalClient.getInstance().getEventBus().unsubscribe(TickEvent.class, tickListener);
    }

    private void onTick(TickEvent event) {
        class_310 mc = event.getClient();
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) return;

        boolean pressed = mc.field_1690.field_1886.method_1434();
        boolean justPressed = pressed && !wasAttackPressed;
        wasAttackPressed = pressed;

        // Restore the slot we came from once mining stops, when asked to.
        if (!pressed && switchBack && previousSlot >= 0) {
            player.method_31548().method_61496(previousSlot);
            mc.method_1562().method_52787(new class_2868(previousSlot));
            previousSlot = -1;
        }

        if (!justPressed || !(mc.field_1765 instanceof class_3965 hit)) return;
        if (onlyWhenHoldingTool && player.method_6047().method_7924(
                mc.field_1687.method_8320(hit.method_17777())) <= 1.0f) return;

        class_2680 state = mc.field_1687.method_8320(hit.method_17777());
        var hotbar = player.method_31548().method_67533();

        int bestSlot = player.method_31548().method_67532();
        float bestSpeed = hotbar.get(bestSlot).method_7924(state);

        // Only the 9 hotbar slots are switchable without opening the inventory.
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = hotbar.get(slot);
            if (stack.method_7960()) continue;

            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = slot;
            }
        }

        if (bestSlot != player.method_31548().method_67532()) {
            if (switchBack && previousSlot < 0) previousSlot = player.method_31548().method_67532();
            player.method_31548().method_61496(bestSlot);
            mc.method_1562().method_52787(new class_2868(bestSlot));
        }
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new BooleanSetting("Only If Tool Helps", () -> onlyWhenHoldingTool, v -> onlyWhenHoldingTool = v, false),
                new BooleanSetting("Switch Back", () -> switchBack, v -> switchBack = v, false)
        );
    }
}
