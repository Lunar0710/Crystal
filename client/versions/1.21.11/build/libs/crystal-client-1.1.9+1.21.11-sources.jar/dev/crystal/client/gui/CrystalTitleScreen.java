package dev.crystal.client.gui;

import dev.crystal.client.CrystalClient;
import dev.crystal.client.config.ThemeManager;
import dev.crystal.client.util.ColorUtil;
import dev.crystal.client.util.CrystalProfile;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;

/**
 * Crystal's main menu, replacing vanilla's title screen while the
 * CustomMainMenu module is on.
 *
 * Buttons are drawn by hand rather than through ButtonWidget: 1.21.11 made
 * widget rendering final, and these need their own hover and theme styling.
 * Labels use vanilla's translation keys, so they follow the game language.
 */
public class CrystalTitleScreen extends class_437 {

    private static final int BUTTON_W = 204;
    private static final int BUTTON_H = 22;
    private static final int GAP = 5;

    private record MenuButton(int x, int y, int w, int h, class_2561 label, Runnable action, boolean danger) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<MenuButton> buttons = new ArrayList<>();
    private long openedAt;

    public CrystalTitleScreen() {
        super(class_2561.method_43471("narrator.screen.title"));
    }

    @Override
    protected void method_25426() {
        openedAt = System.currentTimeMillis();
        buttons.clear();

        int x = (field_22789 - BUTTON_W) / 2;
        int y = field_22790 / 2 - 6;
        int step = BUTTON_H + GAP;

        buttons.add(new MenuButton(x, y, BUTTON_W, BUTTON_H, class_2561.method_43471("menu.singleplayer"),
                () -> field_22787.method_1507(new class_526(this)), false));
        buttons.add(new MenuButton(x, y + step, BUTTON_W, BUTTON_H, class_2561.method_43471("menu.multiplayer"),
                () -> field_22787.method_1507(new class_500(this)), false));

        // Options and the Crystal menu share a row: wide button plus a square one.
        int square = BUTTON_H;
        buttons.add(new MenuButton(x, y + step * 2, BUTTON_W - square - GAP, BUTTON_H, class_2561.method_43471("menu.options"),
                () -> field_22787.method_1507(new class_429(this, field_22787.field_1690)), false));
        buttons.add(new MenuButton(x + BUTTON_W - square, y + step * 2, square, BUTTON_H, class_2561.method_43470("C"),
                () -> field_22787.method_1507(new CrystalClientScreen()), false));

        buttons.add(new MenuButton(x, y + step * 3 + 8, BUTTON_W, BUTTON_H, class_2561.method_43471("menu.quit"),
                field_22787::method_1592, true));
    }

    @Override
    public boolean method_25422() {
        // It's the root screen; Escape has nowhere to go back to.
        return false;
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        method_57728(context, delta);
        // Darken towards the centre column so text stays readable on any panorama.
        context.method_25296(0, 0, field_22789, field_22790 / 2, 0x55000000, 0x88000000);
        context.method_25296(0, field_22790 / 2, field_22789, field_22790, 0x88000000, 0xAA000000);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        ThemeManager theme = CrystalClient.getInstance().getThemeManager();
        int accent = theme.getAccent();
        // Short fade-in so the menu settles in rather than popping onto the panorama.
        float appear = Math.min(1f, (System.currentTimeMillis() - openedAt) / 350f);
        int alpha = Math.round(255 * appear);

        drawLogo(context, accent, alpha);

        for (MenuButton b : buttons) {
            boolean hover = b.contains(mouseX, mouseY);
            int fill = hover ? 0xE02A2F3C : 0xC01B1F29;
            GuiRender.roundedRect(context, b.x, b.y, b.x + b.w, b.y + b.h, GuiRender.withAlpha(fill, Math.round(((fill >>> 24) & 0xFF) * appear)));

            int outline = b.danger && hover ? 0xFFEF4444 : hover ? accent : 0x40FFFFFF;
            GuiRender.roundedOutline(context, b.x, b.y, b.x + b.w, b.y + b.h, GuiRender.withAlpha(outline, Math.round(((outline >>> 24) & 0xFF) * appear)));

            int textColor = b.danger && hover ? 0xFFFCA5A5 : hover ? 0xFFFFFFFF : 0xFFD7DCE5;
            int tw = field_22793.method_27525(b.label);
            context.method_51439(field_22793, b.label, b.x + (b.w - tw) / 2, b.y + (b.h - 8) / 2,
                    GuiRender.withAlpha(textColor, alpha), true);
        }

        String account = field_22787.method_1548() != null ? field_22787.method_1548().method_1676() : "";
        context.method_51439(field_22793, class_2561.method_43470(account), 6, field_22790 - 12, GuiRender.withAlpha(0xFFB8BFCC, alpha), true);
        if (CrystalProfile.hasPerks()) {
            // Small Crystal+ tag after the name, in the accent colour.
            String tag = "Crystal+";
            int tx = 6 + field_22793.method_1727(account) + 6;
            int tw = field_22793.method_1727(tag);
            GuiRender.roundedRect(context, tx - 3, field_22790 - 14, tx + tw + 3, field_22790 - 2, GuiRender.withAlpha(accent, Math.round(0x40 * appear)));
            context.method_51433(field_22793, tag, tx, field_22790 - 12, GuiRender.withAlpha(accent, alpha), false);
        }
        String version = "Crystal " + CrystalClient.VERSION + "  Minecraft 1.21.11";
        context.method_51439(field_22793, class_2561.method_43470(version), field_22789 - field_22793.method_1727(version) - 6, field_22790 - 12,
                GuiRender.withAlpha(0xFF8A93A3, alpha), true);
    }

    private void drawLogo(class_332 context, int accent, int alpha) {
        String logo = "CRYSTAL";
        float scale = Math.max(3f, Math.min(5f, field_22789 / 110f));
        int logoWidth = Math.round(field_22793.method_1727(logo) * scale);
        float lx = (field_22789 - logoWidth) / 2f;
        float ly = field_22790 / 2f - 6 - 22 - 8 * scale - 6;

        context.method_51448().pushMatrix();
        context.method_51448().translate(lx, ly);
        context.method_51448().scale(scale, scale);
        // Offset copy in the theme accent gives the logo depth without a texture.
        // Crystal+ gets a slowly drifting hue instead of the fixed accent.
        int depth = CrystalProfile.hasPerks() ? ColorUtil.rainbow(0.6f) : accent;
        context.method_51433(field_22793, logo, 1, 1, GuiRender.withAlpha(depth, Math.round(alpha * 0.85f)), false);
        context.method_51433(field_22793, logo, 0, 0, GuiRender.withAlpha(0xFFFFFFFF, alpha), false);
        context.method_51448().popMatrix();

        class_2561 subtitle = class_2561.method_43470("Client");
        int sw = field_22793.method_27525(subtitle);
        context.method_51439(field_22793, subtitle, (field_22789 - sw) / 2, Math.round(ly + 8 * scale + 3),
                GuiRender.withAlpha(accent, alpha), true);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            for (MenuButton b : buttons) {
                if (b.contains(click.comp_4798(), click.comp_4799())) {
                    playClick();
                    b.action.run();
                    return true;
                }
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25404(class_11908 input) {
        // Keyboard shortcuts in place of Tab focus, which hand-drawn buttons don't get.
        switch (input.comp_4795()) {
            case GLFW.GLFW_KEY_S -> { buttons.get(0).action.run(); return true; }
            case GLFW.GLFW_KEY_M -> { buttons.get(1).action.run(); return true; }
            case GLFW.GLFW_KEY_O -> { buttons.get(2).action.run(); return true; }
            default -> { return super.method_25404(input); }
        }
    }

    private void playClick() {
        class_310 mc = class_310.method_1551();
        mc.method_1483().method_4873(net.minecraft.class_1109.method_47978(
                net.minecraft.class_3417.field_15015, 1.0f));
    }
}
