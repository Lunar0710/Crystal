package dev.crystal.client.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** GameRenderer only switches post effects internally (creeper/spider spectator views); ColorSaturation needs it too. */
@Mixin(class_757.class)
public interface GameRendererAccessor {
    @Invoker("setPostEffect")
    void crystal$setPostProcessor(class_2960 id);
}
