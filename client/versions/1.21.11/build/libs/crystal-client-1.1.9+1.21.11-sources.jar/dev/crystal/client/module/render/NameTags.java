package dev.crystal.client.module.render;

import dev.crystal.client.module.BooleanSetting;
import dev.crystal.client.module.Module;
import dev.crystal.client.module.ModuleCategory;
import dev.crystal.client.module.Setting;
import dev.crystal.client.module.SliderSetting;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

/**
 * Nametag options: your own nametag in third person, health next to player
 * names, and how dark the label background is. Hooks live in
 * MixinLivingEntityRenderer, MixinEntityRenderer and MixinLabelCommands.
 */
public class NameTags extends Module {

    private boolean showOwn = true;
    private boolean showHealth = true;
    private float backgroundOpacity = 25f;

    public NameTags() {
        super("NameTags", "Your own nametag in third person, player health and background opacity", ModuleCategory.RENDER);
        setEnabled(true);
    }

    public boolean isShowOwn() { return showOwn; }

    /** Background alpha 0-1, replacing the vanilla 25%. */
    public float getBackgroundOpacity() { return backgroundOpacity / 100f; }

    /** The name with " 20❤" appended in a colour from green to red. */
    public class_2561 decorate(class_2561 name, class_1657 player) {
        if (!showHealth) return name;
        float health = player.method_6032() + player.method_6067();
        float fraction = player.method_6063() <= 0 ? 0 : player.method_6032() / player.method_6063();
        class_124 color = fraction > 0.6f ? class_124.field_1060 : fraction > 0.3f ? class_124.field_1054 : class_124.field_1061;
        class_5250 text = name.method_27661();
        text.method_10852(class_2561.method_43470(" " + Math.round(health) + "❤").method_27692(color));
        return text;
    }

    @Override
    public List<Setting<?>> getSettings() {
        return List.of(
                new BooleanSetting("Show Own Nametag", () -> showOwn, v -> showOwn = v, true),
                new BooleanSetting("Show Health", () -> showHealth, v -> showHealth = v, true),
                new SliderSetting("Background Opacity", () -> backgroundOpacity, v -> backgroundOpacity = v, 0f, 100f, 5f, 0));
    }
}
